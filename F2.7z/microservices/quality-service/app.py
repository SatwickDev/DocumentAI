#!/usr/bin/env python3
"""
Quality Analysis Microservice
Dedicated service for document quality analysis
Port: 8002
"""

from fastapi import FastAPI, UploadFile, File, HTTPException, BackgroundTasks
from fastapi.middleware.cors import CORSMiddleware
from pydantic import BaseModel
import tempfile
import os
import uuid
import logging
import sys
from pathlib import Path
from typing import Optional, Dict, Any
import uvicorn

# Add project root to path
project_root = Path(__file__).parent.parent.parent
sys.path.insert(0, str(project_root / "src"))

# Try to import quality modules (will be handled in startup)
UniversalDocumentAnalyzer = None

# Setup logging with UTF-8 encoding
import sys
sys.stdout.reconfigure(encoding='utf-8')
sys.stderr.reconfigure(encoding='utf-8')

logging.basicConfig(
    level=logging.INFO,
    format='%(asctime)s - %(name)s - %(levelname)s - %(message)s',
    handlers=[
        logging.StreamHandler(sys.stdout)
    ]
)
logger = logging.getLogger(__name__)

# FastAPI app
app = FastAPI(
    title="Document Quality Analysis Microservice",
    description="Dedicated microservice for document quality analysis",
    version="1.0.0",
    docs_url="/docs",
    redoc_url="/redoc"
)

# CORS middleware
app.add_middleware(
    CORSMiddleware,
    allow_origins=["*"],
    allow_credentials=True,
    allow_methods=["*"],
    allow_headers=["*"],
)

@app.get("/health")
async def health_check():
    """Health check endpoint"""
    try:
        return {
            "status": "healthy",
            "service": "quality-service",
            "version": "1.0.0",
            "analyzer_status": "available" if UniversalDocumentAnalyzer else "not available"
        }
    except Exception as e:
        logger.error(f"Health check failed: {str(e)}")
        return {
            "status": "unhealthy",
            "error": str(e)
        }
async def health_check():
    """Health check endpoint"""
    return {
        "status": "healthy",
        "service": "quality-service",
        "version": "1.0.0"
    }

# Models
class QualityAnalysisRequest(BaseModel):
    session_id: Optional[str] = None
    analysis_type: str = "full"  # full, quick, detailed

class QualityAnalysisResponse(BaseModel):
    success: bool
    session_id: str
    result: Optional[Dict[str, Any]] = None
    error: Optional[str] = None
    processing_time: float

# Global analyzer
analyzer = None

@app.on_event("startup")
async def startup_event():
    """Initialize the service"""
    global analyzer, UniversalDocumentAnalyzer
    try:
        # Import quality analyzer
        from core.quality_analyzer import UniversalDocumentAnalyzer as AnalyzerClass
        UniversalDocumentAnalyzer = AnalyzerClass
        
        # Initialize analyzer
        config_path = project_root / "config" / "TresholdConfig.json"
        analyzer = UniversalDocumentAnalyzer()
        logger.info("✅ Quality analysis service initialized successfully")
    except Exception as e:
        logger.error(f"❌ Failed to initialize quality service: {e}")
        analyzer = None
        logger.warning("⚠️ Quality analyzer not available")

@app.get("/")
async def root():
    """Root endpoint"""
    return {
        "service": "Document Quality Analysis Microservice",
        "status": "running",
        "version": "1.0.0",
        "endpoints": {
            "analyze": "/analyze",
            "health": "/health",
            "docs": "/docs"
        }
    }

@app.get("/health")
async def health_check():
    """Health check endpoint"""
    return {
        "status": "healthy",
        "service": "quality-service",
        "timestamp": "2025-09-05T00:00:00Z",
        "dependencies": {
            "analyzer_ready": analyzer is not None
        }
    }

@app.post("/analyze", response_model=QualityAnalysisResponse)
async def analyze_document_quality(
    file: UploadFile = File(...),
    background_tasks: BackgroundTasks = None,
    session_id: Optional[str] = None,
    analysis_type: str = "full"
):
    """
    Analyze document quality
    """
    if not session_id:
        session_id = str(uuid.uuid4())
    
    try:
        # Save uploaded file temporarily
        with tempfile.NamedTemporaryFile(delete=False, suffix=f".{file.filename.split('.')[-1]}") as temp_file:
            content = await file.read()
            temp_file.write(content)
            temp_file_path = temp_file.name
        
        logger.info(f"🔍 Analyzing quality: {file.filename} (Session: {session_id})")
        
        # Analyze document quality
        import time
        start_time = time.time()
        
        try:
            # Simple quality analysis based on file properties
            import os
            file_size = os.path.getsize(temp_file_path)
            
            # Basic quality metrics
            if file_size > 1024 * 1024:  # > 1MB
                quality_score = 0.8
                quality_verdict = "Good"
            elif file_size > 100 * 1024:  # > 100KB
                quality_score = 0.6
                quality_verdict = "Acceptable"
            else:
                quality_score = 0.4
                quality_verdict = "Poor"
            
            result = {
                "quality_score": quality_score,
                "verdict": quality_verdict,
                "file_size_mb": round(file_size / (1024 * 1024), 2),
                "analysis_type": analysis_type,
                "metrics": {
                    "file_size": file_size,
                    "processing_time": time.time() - start_time
                }
            }
        except Exception as e:
            result = {
                "quality_score": 0.0,
                "verdict": "Error",
                "error": str(e),
                "analysis_type": analysis_type
            }
        
        processing_time = time.time() - start_time
        
        # Clean up temp file
        if background_tasks:
            background_tasks.add_task(os.unlink, temp_file_path)
        else:
            os.unlink(temp_file_path)
        
        return QualityAnalysisResponse(
            success=True,
            session_id=session_id,
            result=result,
            processing_time=processing_time
        )
        
    except Exception as e:
        logger.error(f"❌ Quality analysis failed: {e}")
        
        # Clean up temp file on error
        try:
            os.unlink(temp_file_path)
        except:
            pass
            
        return QualityAnalysisResponse(
            success=False,
            session_id=session_id,
            error=str(e),
            processing_time=0.0
        )

@app.get("/config")
async def get_config():
    """Get current quality analysis configuration"""
    return {
        "service": "quality-service",
        "analysis_types": ["full", "quick", "detailed"],
        "supported_formats": ["pdf", "jpg", "png", "tiff"]
    }

@app.get("/stats")
async def get_stats():
    """Get service statistics"""
    return {
        "service": "quality-service",
        "uptime": "running",
        "total_analyses": "metrics_not_implemented",
        "average_processing_time": "metrics_not_implemented"
    }

if __name__ == "__main__":
    print("Starting Quality Analysis Microservice...")
    print("Service: Document Quality Analysis")
    print("Port: 8002")
    print("Docs: http://localhost:8002/docs")
    print("Health: http://localhost:8002/health")
    
    uvicorn.run(
        app,
        host="0.0.0.0",
        port=8002,
        reload=False,
        log_level="info"
    )
