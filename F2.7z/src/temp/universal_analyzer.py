import fitz
import numpy as np
import time
from pathlib import Path
from concurrent.futures import ThreadPoolExecutor, as_completed
from parallel_metrics import analyze_page_metrics_parallel
from quality_config import load_quality_config, verdict_for_page
from verdict_icons import verdict_icon, verdict_color, metric_icon
from preprocessing_ops import adaptive_preprocess
import cv2

class PageSourceInfo:
    def __init__(self, source_type, has_images, text_layer_type, compression_detected, image_count):
        self.source_type = source_type
        self.has_images = has_images
        self.text_layer_type = text_layer_type
        self.compression_detected = compression_detected
        self.image_count = image_count

class PageAnalysis:
    def __init__(self, page_num, metrics, source, processing_time, error=None):
        self.page_num = page_num
        self.metrics = metrics
        self.source = source
        self.processing_time = processing_time
        self.error = error

def get_metric_value(metric):
    # Helper to extract .value or just return the metric if already scalar
    return getattr(metric, 'value', metric)

def analyze_single_page(args):
    page_num, file_path = args
    try:
        doc = fitz.open(file_path)
        page = doc[page_num]
        t0 = time.time()
        pix = page.get_pixmap(matrix=fitz.Matrix(0.33, 0.33), colorspace=fitz.csGRAY)
        gray_img = np.frombuffer(pix.samples, dtype=np.uint8).reshape(pix.height, pix.width)
        metric_img = cv2.resize(gray_img, (gray_img.shape[1] // 4, gray_img.shape[0] // 4), interpolation=cv2.INTER_AREA)
        metrics = analyze_page_metrics_parallel(metric_img)
        source_info = PageSourceInfo(
            source_type="pdf", has_images=True, text_layer_type="unknown", compression_detected=True, image_count=1,
        )
        processing_time = time.time() - t0
        doc.close()
        # page_num is 0-based; +1 for human-readable
        return PageAnalysis(page_num + 1, metrics, source_info, processing_time)
    except Exception as e:
        return PageAnalysis(page_num + 1, None, None, 0.0, error=str(e))

def analyze_pdf_fast_parallel(file_path: str, max_workers=2):
    doc = fitz.open(file_path)
    total_pages = len(doc)
    doc.close()
    t0 = time.time()
    results = [None] * total_pages
    with ThreadPoolExecutor(max_workers=max_workers) as executor:
        futures = {executor.submit(analyze_single_page, (i, file_path)): i for i in range(total_pages)}
        for fut in as_completed(futures):
            i = futures[fut]
            result = fut.result()
            if result:
                results[i] = result
    elapsed = time.time() - t0
    print(f"PDF analysis completed in {elapsed:.2f}s for {total_pages} pages")
    return results

def load_image_for_page(file_path, page_num):
    # page_num is 1-based
    doc = fitz.open(file_path)
    page = doc[page_num-1]
    pix = page.get_pixmap(matrix=fitz.Matrix(1, 1), colorspace=fitz.csGRAY)
    img = np.frombuffer(pix.samples, dtype=np.uint8).reshape(pix.height, pix.width)
    doc.close()
    return img

def preprocess_page_adaptive(image, orig_skew=0.0, skew_threshold=2.0):
    # Returns processed_image, deskewed
    return adaptive_preprocess(image, orig_skew=orig_skew, skew_threshold=skew_threshold)

def apply_recommendation(image, recommendations):
    """
    Apply a minimal version of the top recommendation if adaptive_preprocess was a no-op.
    """
    recs = [r.lower() for r in recommendations]
    processed = image.copy()
    if any("contrast" in r for r in recs):
        # Apply CLAHE
        clahe = cv2.createCLAHE(clipLimit=1.2, tileGridSize=(8,8))
        processed = clahe.apply(processed.astype(np.uint8))
    elif any("darken" in r or "black" in r or "faint" in r for r in recs):
        processed[processed < 70] = 0
    elif any("noise" in r for r in recs):
        processed = cv2.fastNlMeansDenoising(processed, None, 5, 7, 21)
    elif any("deskew" in r or "rotate" in r for r in recs):
        # Deskew by a very small angle if possible (simulate)
        h, w = processed.shape[:2]
        center = (w // 2, h // 2)
        angle = -1.0  # try a gentle deskew
        M = cv2.getRotationMatrix2D(center, angle, 1.0)
        processed = cv2.warpAffine(processed, M, (w, h), flags=cv2.INTER_LINEAR, borderMode=cv2.BORDER_REPLICATE)
    else:
        # As a last resort, apply a slight black point boost
        processed[processed < 70] = 0
    return processed

def print_results(results, file_path, config, title="UNIVERSAL DOCUMENT ANALYSIS", force_direct_analysis=False):
    from quality_config import get_metric_category

    results = [r for r in results if r]
    print(f"\n==== {title} ====")
    print(f"Document: {Path(file_path).name}")
    print(f"Total Pages: {len(results)}")
    total_time = sum((r.processing_time or 0) for r in results)
    print(f"Total Processing Time (sum of page workers): {total_time:.2f}s")
    print("\nPage-by-page summary:")
    all_direct = True

    for r in results:
        if r.error:
            print(f"Page {r.page_num:3d}: ERROR: {r.error}")
            all_direct = False
        else:
            m = r.metrics
            metric_dict = {
                "blur_score": get_metric_value(m.blur_score),
                "contrast_score": get_metric_value(m.contrast_score),
                "noise_level": get_metric_value(m.noise_level),
                "sharpness_score": get_metric_value(m.sharpness_score),
                "brightness_score": get_metric_value(m.brightness_score),
                "skew_angle": get_metric_value(m.skew_angle),
                "edge_crop_score": get_metric_value(m.edge_crop_score),
                "shadow_glare_score": get_metric_value(m.shadow_glare_score),
                "blank_page_score": get_metric_value(m.blank_page_score),
            }
            # Force verdict if override is set
            if force_direct_analysis:
                verdict = "direct analysis"
                icon = verdict_icon(verdict)
                colored_verdict = verdict_color(verdict, verdict)
                recommendations = []
            else:
                verdict, per_metric, confidence, confidence_category, recommendations = verdict_for_page(metric_dict, config)
                if verdict == "direect analysis":
                    verdict = "direct analysis"
                icon = verdict_icon(verdict)
                colored_verdict = verdict_color(verdict, verdict)
                if verdict != "direct analysis":
                    all_direct = False

            metric_strs = []
            metric_keys = [
                ("blur_score",    m.blur_score),
                ("contrast_score", m.contrast_score),
                ("noise_level",   m.noise_level),
                ("sharpness_score", m.sharpness_score),
                ("brightness_score", m.brightness_score),
                ("skew_angle",    m.skew_angle),
                ("edge_crop_score", m.edge_crop_score),
                ("shadow_glare_score", m.shadow_glare_score),
                ("blank_page_score", m.blank_page_score),
            ]
            for metric_name, metric_value in metric_keys:
                scalar_val = get_metric_value(metric_value)
                if metric_name in config:
                    reverse = metric_name in {"noise_level", "skew_angle", "edge_crop_score", "shadow_glare_score", "blank_page_score"}
                    category = get_metric_category(scalar_val, config[metric_name], reverse=reverse)
                    icon_metric = metric_icon(category)
                    if metric_name == "skew_angle":
                        metric_strs.append(f"{scalar_val:.2f}° {icon_metric}")
                    elif metric_name in {"contrast_score", "noise_level", "brightness_score", "edge_crop_score", "shadow_glare_score", "blank_page_score"}:
                        metric_strs.append(f"{scalar_val:.3f} {icon_metric}")
                    else:
                        metric_strs.append(f"{scalar_val:.1f} {icon_metric}")

            print((
                f"Page {r.page_num:3d}: "
                f"Blur={metric_strs[0]} "
                f"Contrast={metric_strs[1]} "
                f"Noise={metric_strs[2]} "
                f"Sharpness={metric_strs[3]} "
                f"Brightness={metric_strs[4]} "
                f"Skew={metric_strs[5]} "
                f"EdgeCrop={metric_strs[6]} "
                f"ShadowGlare={metric_strs[7]} "
                f"BlankPage={metric_strs[8]} "
                f"Verdict={icon} {colored_verdict} Time={r.processing_time:.2f}s"
            ))
            # Show recommendations only for pre-processing pages or re-scan verdict
            if (verdict == "pre-processing" or verdict == "re-scan") and recommendations:
                print("    Recommendations:")
                for rec in recommendations:
                    print(f"      - {rec}")

    if all_direct or force_direct_analysis:
        print("\n✅ All pages are ready for direct analysis (🟢). No pre-processing required.")

def save_preprocessed_pdf(original_pdf_path, preprocessed_images_dict, output_pdf_path):
    doc = fitz.open(original_pdf_path)
    new_doc = fitz.open()
    total_pages = len(doc)
    for page_num in range(total_pages):
        page = doc[page_num]
        rect = page.rect
        if page_num + 1 in preprocessed_images_dict:
            img = preprocessed_images_dict[page_num + 1]
            # Defensive: if a tuple (image, deskewed) was stored, get the image part
            if isinstance(img, tuple):
                img = img[0]
            # Downsample if too large
            max_dim = 1500
            h, w = img.shape[:2]
            if max(h, w) > max_dim:
                scale = max_dim / max(h, w)
                img = cv2.resize(img, (int(w*scale), int(h*scale)))
            # Convert to grayscale if not already (JPEG can be color or gray)
            if len(img.shape) == 3 and img.shape[2] == 3:
                img = cv2.cvtColor(img, cv2.COLOR_RGB2GRAY)
            img_bytes = cv2.imencode('.jpg', img, [int(cv2.IMWRITE_JPEG_QUALITY), 92])[1].tobytes()
            new_page = new_doc.new_page(width=rect.width, height=rect.height)
            new_page.insert_image(rect, stream=img_bytes)
        else:
            new_doc.insert_pdf(doc, from_page=page_num, to_page=page_num)
    new_doc.save(output_pdf_path)
    new_doc.close()
    doc.close()

def auto_preprocess_pages(results, config, args, max_attempts=2):
    from parallel_metrics import analyze_page_metrics_parallel
    from quality_config import get_metric_category
    preprocessed_results = results.copy()
    preprocessed_images_dict = dict()
    attempts = 0

    # Gather all pages flagged for pre-processing (correctly, using page_num)
    page_flagged = []
    page_recommendations = dict()  # page_num -> recommendations
    for r in results:
        if r.error:
            continue
        m = r.metrics
        metric_dict = {
            "blur_score": get_metric_value(m.blur_score),
            "contrast_score": get_metric_value(m.contrast_score),
            "noise_level": get_metric_value(m.noise_level),
            "sharpness_score": get_metric_value(m.sharpness_score),
            "brightness_score": get_metric_value(m.brightness_score),
            "skew_angle": get_metric_value(m.skew_angle),
            "edge_crop_score": get_metric_value(m.edge_crop_score),
            "shadow_glare_score": get_metric_value(m.shadow_glare_score),
            "blank_page_score": get_metric_value(m.blank_page_score),
        }
        verdict, per_metric, confidence, confidence_category, recommendations = verdict_for_page(metric_dict, config)
        if verdict == "pre-processing":
            page_recommendations[r.page_num] = recommendations
            if recommendations:
                page_flagged.append(r.page_num)
    print(f"[DEBUG] Pages flagged for pre-processing: {page_flagged}")

    while attempts < max_attempts:
        unresolved = []
        temp_results = []
        processed_this_round = []
        for r in preprocessed_results:
            # Use r.page_num to check if this page should be processed
            if r.page_num in page_flagged:
                print(f"[DEBUG] Pre-processing page {r.page_num}")
                orig_image = load_image_for_page(args.file_path, r.page_num)
                processed_image, deskewed = preprocess_page_adaptive(orig_image, orig_skew=get_metric_value(r.metrics.skew_angle))
                # Check if adaptive_preprocess was a no-op (returns original image)
                if np.array_equal(processed_image, orig_image):
                    recs = page_recommendations.get(r.page_num, [])
                    if recs:
                        print(f"[DEBUG] Adaptive pre-processing was a no-op for page {r.page_num}. Applying recommendation: {recs[0]}")
                        processed_image = apply_recommendation(orig_image, recs)
                new_metrics = analyze_page_metrics_parallel(processed_image)
                # Preserve original skew if no deskew was performed
                if not deskewed:
                    new_metrics.skew_angle = r.metrics.skew_angle
                temp_results.append(PageAnalysis(
                    page_num=r.page_num,
                    metrics=new_metrics,
                    source=r.source,
                    processing_time=r.processing_time,
                    error=None
                ))
                preprocessed_images_dict[r.page_num] = processed_image  # Store only the image, not the tuple
                processed_this_round.append(r.page_num)
            else:
                temp_results.append(r)
        print(f"[DEBUG] Pages actually processed this round: {processed_this_round}")
        unresolved = []
        for idx, r in enumerate(temp_results):
            if r.error:
                continue
            m = r.metrics
            metric_dict = {
                "blur_score": get_metric_value(m.blur_score),
                "contrast_score": get_metric_value(m.contrast_score),
                "noise_level": get_metric_value(m.noise_level),
                "sharpness_score": get_metric_value(m.sharpness_score),
                "brightness_score": get_metric_value(m.brightness_score),
                "skew_angle": get_metric_value(m.skew_angle),
                "edge_crop_score": get_metric_value(m.edge_crop_score),
                "shadow_glare_score": get_metric_value(m.shadow_glare_score),
                "blank_page_score": get_metric_value(m.blank_page_score),
            }
            verdict, per_metric, confidence, confidence_category, recommendations = verdict_for_page(metric_dict, config)
            if verdict in ("pre-processing", "reupload", "re-scan"):
                unresolved.append((r.page_num, verdict, per_metric, recommendations))
        preprocessed_results = temp_results
        if not unresolved:
            break
        attempts += 1
    print(f"[DEBUG] Preprocessed images dict keys: {list(preprocessed_images_dict.keys())}")
    return preprocessed_results, preprocessed_images_dict

def main():
    import argparse
    parser = argparse.ArgumentParser(description="Robust PDF Quality Analyzer (with adaptive pre-processing)")
    parser.add_argument("file_path", help="PDF file to analyze")
    parser.add_argument("--workers", "-w", type=int, default=2, help="Number of parallel workers (default: 2)")
    parser.add_argument("--config", "-c", type=str, default="quality_config.yaml", help="Path to quality config file")
    args = parser.parse_args()

    config = load_quality_config(args.config)
    results = analyze_pdf_fast_parallel(args.file_path, max_workers=args.workers)
    print_results(results, args.file_path, config)

    preproc_candidates = []
    preproc_recommendations = dict()  # page_num -> recommendations
    for r in results:
        if r.error:
            continue
        m = r.metrics
        metric_dict = {
            "blur_score": get_metric_value(m.blur_score),
            "contrast_score": get_metric_value(m.contrast_score),
            "noise_level": get_metric_value(m.noise_level),
            "sharpness_score": get_metric_value(m.sharpness_score),
            "brightness_score": get_metric_value(m.brightness_score),
            "skew_angle": get_metric_value(m.skew_angle),
            "edge_crop_score": get_metric_value(m.edge_crop_score),
            "shadow_glare_score": get_metric_value(m.shadow_glare_score),
            "blank_page_score": get_metric_value(m.blank_page_score),
        }
        verdict, per_metric, confidence, confidence_category, recommendations = verdict_for_page(metric_dict, config)
        if verdict == "pre-processing":
            preproc_recommendations[r.page_num] = recommendations
            if recommendations:
                preproc_candidates.append(r.page_num)
    print(f"[DEBUG] Pre-processing candidates (final): {preproc_candidates}")

    if not preproc_candidates:
        print("No need for Pre-Processing since all the pages are ready for direct analysis.")
        print("Your Quality Analysis is complete :)")
        return

    user_input = input("\nDo you want us to continue with pre-processing if required any? (Yes/No): ").strip().lower()
    if user_input == "no":
        print("Your Quality Analysis is complete :)")
        return
    elif user_input == "yes":
        print("Starting adaptive pre-processing on required pages...")
        preprocessed_results, preprocessed_images_dict = auto_preprocess_pages(results, config, args, max_attempts=2)
        print_results(preprocessed_results, args.file_path, config, title="PAGE-BY-PAGE SUMMARY AFTER PRE-PROCESSING")
        unresolved = []
        for r in preprocessed_results:
            if r.error:
                continue
            m = r.metrics
            metric_dict = {
                "blur_score": get_metric_value(m.blur_score),
                "contrast_score": get_metric_value(m.contrast_score),
                "noise_level": get_metric_value(m.noise_level),
                "sharpness_score": get_metric_value(m.sharpness_score),
                "brightness_score": get_metric_value(m.brightness_score),
                "skew_angle": get_metric_value(m.skew_angle),
                "edge_crop_score": get_metric_value(m.edge_crop_score),
                "shadow_glare_score": get_metric_value(m.shadow_glare_score),
                "blank_page_score": get_metric_value(m.blank_page_score),
            }
            verdict, per_metric, confidence, confidence_category, recommendations = verdict_for_page(metric_dict, config)
            if verdict in ("pre-processing", "reupload", "re-scan"):
                unresolved.append((r.page_num, verdict, per_metric, recommendations))
        output_pdf_path = str(Path(args.file_path).with_name(Path(args.file_path).stem + "_processed.pdf"))
        save_preprocessed_pdf(args.file_path, preprocessed_images_dict, output_pdf_path)
        print(f"\nA new PDF with pre-processed pages has been saved as: {output_pdf_path}")
        if unresolved:
            print("\nSome pages still require attention after automated pre-processing:")
            for page_num, verdict, per_metric, recommendations in unresolved:
                print(f"Page {page_num}: Verdict = {verdict}")
                for rec in recommendations:
                    print(f" - {rec}")
        else:
            print("All pages are now ready for direct analysis. Your Pre-Processing is complete :)")
    else:
        print("Unrecognized response. Exiting.")

if __name__ == "__main__":
    main()