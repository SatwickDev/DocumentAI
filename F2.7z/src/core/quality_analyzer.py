#!/usr/bin/env python3
"""
Universal Document Analyzer with Configurable Quality Thresholds
Comprehensive analysis for PDF, DOCX, XLSX, and image files
Now with configurable thresholds and 4-tier verdict system
"""

import pandas as pd
import numpy as np
from typing import List, Dict, Any, Union, Optional, Tuple
from datetime import datetime
import os
from pathlib import Path
import sys
import argparse

# Core analysis components
import fitz  # PyMuPDF
import cv2
from PIL import Image
import io
from dataclasses import dataclass
import concurrent.futures
import multiprocessing as mp
from functools import lru_cache
import time
import json
from numba import jit, prange
import warnings
warnings.filterwarnings('ignore')

# Optional imports for different file formats
try:
    import docx
    from docx.document import Document
    DOCX_AVAILABLE = True
except ImportError:
    DOCX_AVAILABLE = False

try:
    import mammoth
    MAMMOTH_AVAILABLE = True
except ImportError:
    MAMMOTH_AVAILABLE = False

try:
    from openpyxl import load_workbook
    import xlrd
    EXCEL_AVAILABLE = True
except ImportError:
    EXCEL_AVAILABLE = False

@dataclass
class QualityMetrics:
    blur_score: float
    resolution: Tuple[int, int]
    skew_angle: float
    contrast_score: float
    noise_level: float
    text_coverage: float
    sharpness_score: float
    brightness_score: float
    ocr_confidence: float
    margin_safety: float
    duplicate_blank_score: float
    compression_artifact_score: float
    page_consistency: float

@dataclass
class PageSourceInfo:
    source_type: str
    has_images: bool
    text_layer_type: str
    compression_detected: bool
    image_count: int

@dataclass
class QualityEvaluation:
    """Individual metric evaluation against thresholds"""
    metric_name: str
    value: float
    threshold: float
    critical_threshold: float
    excellent_threshold: float
    direction: str
    status: str  # 'excellent', 'good', 'acceptable', 'poor', 'critical'
    normalized_score: float  # 0.0 to 1.0

@dataclass
class DocumentVerdict:
    """Overall document verdict with action recommendation"""
    overall_score: float
    quality_level: str  # 'poor', 'acceptable', 'good', 'excellent'
    action: str
    message: str
    next_step: str
    metric_evaluations: List[QualityEvaluation]
    critical_issues: List[str]

@dataclass
class PageAnalysis:
    page_num: int
    doc_type: str
    confidence: float
    metrics: QualityMetrics
    source: PageSourceInfo
    issues: List[str]
    content_info: Dict[str, Any] = None
    processing_time: float = 0.0
    quality_evaluation: QualityEvaluation = None
    document_verdict: DocumentVerdict = None

class QualityThresholdManager:
    """Manages configurable quality thresholds and evaluations"""
    
    def __init__(self, config_path: str = "TresholdConfig.json"):
        self.config_path = config_path
        self.config = self._load_config()
        
    def _load_config(self) -> Dict:
        """Load threshold configuration from JSON file"""
        try:
            with open(self.config_path, 'r') as f:
                config = json.load(f)
            print(f"✅ Loaded threshold configuration from {self.config_path}")
            return config
        except FileNotFoundError:
            print(f"⚠️ Config file {self.config_path} not found. Using default thresholds.")
            return self._get_default_config()
        except json.JSONDecodeError as e:
            print(f"❌ Error parsing config file: {e}")
            return self._get_default_config()
    
    def _get_default_config(self) -> Dict:
        """Default configuration if file is not found"""
        return {
            "quality_metrics": {
                "blur_score": {
                    "threshold": 80,
                    "direction": "higher_is_better",
                    "critical_threshold": 50,
                    "excellent_threshold": 120
                },
                "contrast_score": {
                    "threshold": 0.2,
                    "direction": "higher_is_better",
                    "critical_threshold": 0.1,
                    "excellent_threshold": 0.4
                },
                "noise_level": {
                    "threshold": 0.25,
                    "direction": "lower_is_better",
                    "critical_threshold": 0.4,
                    "excellent_threshold": 0.1
                },
                "sharpness_score": {
                    "threshold": 30,
                    "direction": "higher_is_better",
                    "critical_threshold": 15,
                    "excellent_threshold": 60
                },
                "brightness_score": {
                    "threshold": 0.5,
                    "direction": "0.3-0.8 optimal",
                    "critical_threshold": 0.2,
                    "excellent_threshold": 0.6
                },
                "skew_angle": {
                    "threshold": 2,
                    "direction": "lower_is_better",
                    "critical_threshold": 5,
                    "excellent_threshold": 0.5
                },
                "text_coverage": {
                    "threshold": 0.1,
                    "direction": "varies_by_document",
                    "critical_threshold": 0.05,
                    "excellent_threshold": 0.3
                },
                "ocr_confidence": {
                    "threshold": 0.7,
                    "direction": "higher_is_better",
                    "critical_threshold": 0.5,
                    "excellent_threshold": 0.9
                },
                "margin_safety": {
                    "threshold": 0.9,
                    "direction": "higher_is_better",
                    "critical_threshold": 0.7,
                    "excellent_threshold": 0.95
                },
                "duplicate_blank": {
                    "threshold": 0.9,
                    "direction": "higher_is_better",
                    "critical_threshold": 0.6,
                    "excellent_threshold": 0.98
                },
                "compression_artifacts": {
                    "threshold": 0.7,
                    "direction": "higher_is_better",
                    "critical_threshold": 0.4,
                    "excellent_threshold": 0.9
                },
                "page_consistency": {
                    "threshold": 0.9,
                    "direction": "higher_is_better",
                    "critical_threshold": 0.7,
                    "excellent_threshold": 0.95
                }
            },
            "overall_document_verdict": {
                "quality_levels": {
                    "poor": {"threshold": 0.3},
                    "acceptable": {"threshold": 0.6},
                    "good": {"threshold": 0.8},
                    "excellent": {"threshold": 1.0}
                }
            }
        }
    
    def evaluate_metric(self, metric_name: str, value: float) -> QualityEvaluation:
        """Evaluate a single metric against thresholds"""
        # Map metric names to config keys
        metric_mapping = {
            'blur_score': 'blur_score',
            'contrast_score': 'contrast_score',
            'noise_level': 'noise_level',
            'sharpness_score': 'sharpness_score',
            'brightness_score': 'brightness_score',
            'skew_angle': 'skew_angle',
            'text_coverage': 'text_coverage',
            'ocr_confidence': 'ocr_confidence',
            'margin_safety': 'margin_safety',
            'duplicate_blank_score': 'duplicate_blank',
            'compression_artifact_score': 'compression_artifacts',
            'page_consistency': 'page_consistency'
        }
        
        config_key = metric_mapping.get(metric_name)
        if not config_key or config_key not in self.config['quality_metrics']:
            # Fallback evaluation
            return QualityEvaluation(
                metric_name=metric_name,
                value=value,
                threshold=0.5,
                critical_threshold=0.2,
                excellent_threshold=0.8,
                direction="higher_is_better",
                status="unknown",
                normalized_score=0.5
            )
        
        metric_config = self.config['quality_metrics'][config_key]
        threshold = metric_config['threshold']
        critical_threshold = metric_config['critical_threshold']
        excellent_threshold = metric_config['excellent_threshold']
        direction = metric_config['direction']
        
        # Handle special case for skew_angle (use absolute value)
        eval_value = abs(value) if metric_name == 'skew_angle' else value
        
        # Determine status and normalized score
        status, normalized_score = self._evaluate_against_thresholds(
            eval_value, threshold, critical_threshold, excellent_threshold, direction
        )
        
        return QualityEvaluation(
            metric_name=metric_name,
            value=value,
            threshold=threshold,
            critical_threshold=critical_threshold,
            excellent_threshold=excellent_threshold,
            direction=direction,
            status=status,
            normalized_score=normalized_score
        )
    
    def _evaluate_against_thresholds(self, value: float, threshold: float, 
                                   critical_threshold: float, excellent_threshold: float,
                                   direction: str) -> Tuple[str, float]:
        """Evaluate value against thresholds based on direction"""
        
        if direction == "higher_is_better":
            if value >= excellent_threshold:
                return "excellent", 1.0
            elif value >= threshold:
                return "good", 0.75
            elif value >= critical_threshold:
                return "acceptable", 0.5
            else:
                return "poor", 0.25
                
        elif direction == "lower_is_better":
            if value <= excellent_threshold:
                return "excellent", 1.0
            elif value <= threshold:
                return "good", 0.75
            elif value <= critical_threshold:
                return "acceptable", 0.5
            else:
                return "poor", 0.25
                
        elif direction == "0.3-0.8 optimal":
            # Special case for brightness
            if 0.4 <= value <= 0.7:
                return "excellent", 1.0
            elif 0.3 <= value <= 0.8:
                return "good", 0.75
            elif 0.2 <= value <= 0.9:
                return "acceptable", 0.5
            else:
                return "poor", 0.25
                
        elif direction == "varies_by_document":
            # For text coverage, evaluate based on document context
            if value >= excellent_threshold:
                return "excellent", 1.0
            elif value >= threshold:
                return "good", 0.75
            elif value >= critical_threshold:
                return "acceptable", 0.5
            else:
                return "poor", 0.25
        
        # Default fallback
        return "acceptable", 0.5
    
    def calculate_overall_score(self, metric_evaluations: List[QualityEvaluation]) -> float:
        """Calculate weighted overall score"""
        # Get critical metrics from config
        critical_metrics = self.config.get('overall_document_verdict', {}).get(
            'critical_metrics', ['ocr_confidence', 'blur_score', 'contrast_score']
        )
        critical_weight = self.config.get('overall_document_verdict', {}).get(
            'critical_metrics_weight', 1.5
        )
        
        total_score = 0.0
        total_weight = 0.0
        
        for evaluation in metric_evaluations:
            # Map back to config metric names for critical check
            metric_key = self._get_config_key_from_metric_name(evaluation.metric_name)
            weight = critical_weight if metric_key in critical_metrics else 1.0
            
            total_score += evaluation.normalized_score * weight
            total_weight += weight
        
        return total_score / total_weight if total_weight > 0 else 0.0
    
    def _get_config_key_from_metric_name(self, metric_name: str) -> str:
        """Map metric name back to config key"""
        mapping = {
            'blur_score': 'blur_score',
            'contrast_score': 'contrast_score',
            'noise_level': 'noise_level',
            'sharpness_score': 'sharpness_score',
            'brightness_score': 'brightness_score',
            'skew_angle': 'skew_angle',
            'text_coverage': 'text_coverage',
            'ocr_confidence': 'ocr_confidence',
            'margin_safety': 'margin_safety',
            'duplicate_blank_score': 'duplicate_blank',
            'compression_artifact_score': 'compression_artifacts',
            'page_consistency': 'page_consistency'
        }
        return mapping.get(metric_name, metric_name)
    
    def determine_document_verdict(self, overall_score: float, 
                                 metric_evaluations: List[QualityEvaluation]) -> DocumentVerdict:
        """Determine overall document verdict and action"""
        quality_levels = self.config.get('overall_document_verdict', {}).get('quality_levels', {})
        
        # Determine quality level
        if overall_score >= quality_levels.get('good', {}).get('threshold', 0.8):
            if overall_score >= 0.9:
                level_key = 'excellent'
            else:
                level_key = 'good'
        elif overall_score >= quality_levels.get('acceptable', {}).get('threshold', 0.6):
            level_key = 'acceptable'
        else:
            level_key = 'poor'
        
        level_config = quality_levels.get(level_key, {})
        
        # Default actions if not in config
        default_actions = {
            'poor': {
                'action': 'reject_and_request_reupload',
                'message': 'Document quality is too poor for processing. Please re-upload a higher quality document.',
                'next_step': 'user_reupload'
            },
            'acceptable': {
                'action': 'send_to_azure_analysis',
                'message': 'Document quality is acceptable. Sending to Azure Document Analysis for enhanced processing.',
                'next_step': 'azure_document_intelligence'
            },
            'good': {
                'action': 'apply_preprocessing_filters',
                'message': 'Good document quality detected. Applying preprocessing filters for optimal analysis.',
                'next_step': 'preprocessing_pipeline'
            },
            'excellent': {
                'action': 'proceed_direct_analysis',
                'message': 'Excellent document quality. Proceeding with direct analysis without modifications.',
                'next_step': 'direct_analysis'
            }
        }
        
        action_config = level_config if level_config else default_actions[level_key]
        
        # Identify critical issues
        critical_issues = [
            eval.metric_name for eval in metric_evaluations 
            if eval.status in ['poor', 'critical']
        ]
        
        return DocumentVerdict(
            overall_score=overall_score,
            quality_level=level_key,
            action=action_config.get('action', 'unknown'),
            message=action_config.get('message', 'No message configured'),
            next_step=action_config.get('next_step', 'unknown'),
            metric_evaluations=metric_evaluations,
            critical_issues=critical_issues
        )

# JIT-compiled functions for maximum speed
@jit(nopython=True, cache=True)
def fast_blur_detection(gray_img: np.ndarray) -> float:
    """Ultra-fast blur detection using Laplacian variance"""
    kernel = np.array([[0, -1, 0], [-1, 4, -1], [0, -1, 0]], dtype=np.float32)
    h, w = gray_img.shape
    result = 0.0
    
    for i in prange(1, h-1):
        for j in prange(1, w-1):
            val = (gray_img[i-1, j] * kernel[0, 1] + 
                   gray_img[i, j-1] * kernel[1, 0] + 
                   gray_img[i, j] * kernel[1, 1] + 
                   gray_img[i, j+1] * kernel[1, 2] + 
                   gray_img[i+1, j] * kernel[2, 1])
            result += val * val
    
    return result / ((h-2) * (w-2))

@jit(nopython=True, cache=True)
def fast_contrast_noise(gray_img: np.ndarray) -> Tuple[float, float]:
    """Combined contrast and noise calculation"""
    mean_val = np.mean(gray_img)
    contrast = np.std(gray_img) / 255.0
    
    # High-frequency noise estimation
    h, w = gray_img.shape
    noise_sum = 0.0
    count = 0
    
    for i in prange(1, h-1):
        for j in prange(1, w-1):
            center = gray_img[i, j]
            neighbors = (gray_img[i-1, j] + gray_img[i+1, j] + 
                        gray_img[i, j-1] + gray_img[i, j+1])
            diff = abs(4 * center - neighbors)
            if diff > 20:  # Threshold for noise
                noise_sum += diff
                count += 1
    
    noise = (noise_sum / max(count, 1)) / 1020.0  # Normalized
    return contrast, min(noise, 1.0)

@jit(nopython=True, cache=True)
def fast_sharpness_brightness(gray_img: np.ndarray) -> Tuple[float, float]:
    """Combined sharpness and brightness calculation"""
    h, w = gray_img.shape
    brightness = np.mean(gray_img) / 255.0
    
    # Sobel-like gradient magnitude
    grad_sum = 0.0
    for i in prange(1, h-1):
        for j in prange(1, w-1):
            gx = (-gray_img[i-1, j-1] + gray_img[i-1, j+1] - 
                  2*gray_img[i, j-1] + 2*gray_img[i, j+1] - 
                  gray_img[i+1, j-1] + gray_img[i+1, j+1])
            gy = (-gray_img[i-1, j-1] - 2*gray_img[i-1, j] - gray_img[i-1, j+1] + 
                  gray_img[i+1, j-1] + 2*gray_img[i+1, j] + gray_img[i+1, j+1])
            grad_sum += np.sqrt(gx*gx + gy*gy)
    
    sharpness = grad_sum / ((h-2) * (w-2))
    return sharpness, brightness

class UniversalDocumentAnalyzer:
    """
    Universal analyzer with configurable quality thresholds
    """
    
    def __init__(self, max_workers: int = None, config_path: str = "TresholdConfig.json"):
        self.max_workers = max_workers or min(mp.cpu_count(), 8)
        self.render_matrix = fitz.Matrix(1.5, 1.5)
        self.threshold_manager = QualityThresholdManager(config_path)
        
        # Supported formats
        self.supported_formats = {
            '.pdf': self._analyze_pdf,
            '.jpeg': self._analyze_image,
            '.jpg': self._analyze_image,
            '.png': self._analyze_image,
            '.bmp': self._analyze_image,
            '.tiff': self._analyze_image,
            '.tif': self._analyze_image
        }
        
        # Add optional format support
        if DOCX_AVAILABLE:
            self.supported_formats['.docx'] = self._analyze_docx
        
        if EXCEL_AVAILABLE:
            self.supported_formats['.xlsx'] = self._analyze_xlsx
            self.supported_formats['.xls'] = self._analyze_xlsx
    
    def analyze_document(self, file_path: str, progress_callback=None) -> List[PageAnalysis]:
        """
        Analyze any supported document format with configurable thresholds
        """
        file_path = Path(file_path)
        file_ext = file_path.suffix.lower()
        
        if file_ext not in self.supported_formats:
            available_formats = list(self.supported_formats.keys())
            raise ValueError(f"Unsupported file format: {file_ext}. "
                           f"Supported formats: {available_formats}")
        
        print(f"🔍 Analyzing {file_ext.upper()} file: {file_path.name}")
        print(f"📋 Using threshold config: {self.threshold_manager.config_path}")
        
        # Route to appropriate analyzer
        analyzer_func = self.supported_formats[file_ext]
        results = analyzer_func(str(file_path), progress_callback)
        
        # Apply threshold evaluation to all results
        enhanced_results = []
        for result in results:
            enhanced_result = self._apply_threshold_evaluation(result)
            enhanced_results.append(enhanced_result)
        
        return enhanced_results
    
    def _apply_threshold_evaluation(self, page_analysis: PageAnalysis) -> PageAnalysis:
        """Apply threshold evaluation to a page analysis"""
        metrics = page_analysis.metrics
        
        # Evaluate each metric
        metric_evaluations = [
            self.threshold_manager.evaluate_metric('blur_score', metrics.blur_score),
            self.threshold_manager.evaluate_metric('contrast_score', metrics.contrast_score),
            self.threshold_manager.evaluate_metric('noise_level', metrics.noise_level),
            self.threshold_manager.evaluate_metric('sharpness_score', metrics.sharpness_score),
            self.threshold_manager.evaluate_metric('brightness_score', metrics.brightness_score),
            self.threshold_manager.evaluate_metric('skew_angle', metrics.skew_angle),
            self.threshold_manager.evaluate_metric('text_coverage', metrics.text_coverage),
            self.threshold_manager.evaluate_metric('ocr_confidence', metrics.ocr_confidence),
            self.threshold_manager.evaluate_metric('margin_safety', metrics.margin_safety),
            self.threshold_manager.evaluate_metric('duplicate_blank_score', metrics.duplicate_blank_score),
            self.threshold_manager.evaluate_metric('compression_artifact_score', metrics.compression_artifact_score),
            self.threshold_manager.evaluate_metric('page_consistency', metrics.page_consistency)
        ]
        
        # Calculate overall score
        overall_score = self.threshold_manager.calculate_overall_score(metric_evaluations)
        
        # Determine document verdict
        document_verdict = self.threshold_manager.determine_document_verdict(
            overall_score, metric_evaluations
        )
        
        # Create enhanced page analysis
        enhanced_analysis = PageAnalysis(
            page_num=page_analysis.page_num,
            doc_type=page_analysis.doc_type,
            confidence=page_analysis.confidence,
            metrics=page_analysis.metrics,
            source=page_analysis.source,
            issues=page_analysis.issues,
            content_info=page_analysis.content_info,
            processing_time=page_analysis.processing_time,
            quality_evaluation=None,  # Individual page evaluation
            document_verdict=document_verdict
        )
        
        return enhanced_analysis
    
    def _analyze_pdf(self, file_path: str, progress_callback=None) -> List[PageAnalysis]:
        """Analyze PDF files using optimized code"""
        print("📄 Analyzing PDF document...")
        start_time = time.time()
        
        try:
            doc = fitz.open(file_path)
            total_pages = len(doc)
            results = []
            
            # Store page hashes for duplicate detection
            page_hashes = []
            
            for i in range(total_pages):
                page_start_time = time.time()
                
                try:
                    page = doc[i]
                    
                    # Extract comprehensive page data
                    text_content = page.get_text()
                    text_blocks = page.get_text_blocks()
                    images = page.get_images()
                    
                    # Render page for visual analysis
                    pix = page.get_pixmap(matrix=self.render_matrix)
                    img_data = pix.tobytes("png")
                    
                    # Convert to OpenCV format
                    pil_img = Image.open(io.BytesIO(img_data))
                    cv_img = np.array(pil_img)
                    
                    if len(cv_img.shape) == 3:
                        gray_img = cv2.cvtColor(cv_img, cv2.COLOR_RGB2GRAY)
                    else:
                        gray_img = cv_img
                    
                    # Calculate all metrics using JIT functions
                    blur_score = float(fast_blur_detection(gray_img))
                    contrast, noise = fast_contrast_noise(gray_img)
                    sharpness, brightness = fast_sharpness_brightness(gray_img)
                    skew_angle = self._fast_skew_detection(gray_img)
                    text_coverage = self._fast_text_coverage(text_blocks, gray_img.shape)
                    
                    # New metrics calculations
                    ocr_confidence = self._calculate_ocr_confidence(text_content, text_blocks)
                    margin_safety = self._calculate_margin_safety(text_blocks, gray_img.shape)
                    duplicate_blank_score = self._calculate_duplicate_blank_score(gray_img, page_hashes)
                    compression_artifact_score = self._calculate_compression_artifacts(gray_img)
                    page_consistency = self._calculate_page_consistency(i, results, gray_img.shape)
                    
                    metrics = QualityMetrics(
                        blur_score=blur_score,
                        resolution=gray_img.shape[::-1],
                        skew_angle=skew_angle,
                        contrast_score=float(contrast),
                        noise_level=float(noise),
                        text_coverage=text_coverage,
                        sharpness_score=float(sharpness),
                        brightness_score=float(brightness),
                        ocr_confidence=ocr_confidence,
                        margin_safety=margin_safety,
                        duplicate_blank_score=duplicate_blank_score,
                        compression_artifact_score=compression_artifact_score,
                        page_consistency=page_consistency
                    )
                    
                    # Update page hashes for duplicate detection
                    page_hash = hash(img_data)
                    page_hashes.append(page_hash)
                    
                    # Source analysis
                    source_info = self._analyze_pdf_page_source(text_content, images)
                    
                    # Classification
                    doc_type, confidence = self._classify_document_quality(metrics, source_info)
                    
                    # Issue detection using configurable thresholds
                    issues = self._detect_issues_with_thresholds(metrics, source_info)
                    
                    # Additional content info
                    content_info = {
                        'word_count': len(text_content.split()) if text_content else 0,
                        'char_count': len(text_content),
                        'paragraph_count': len([b for b in text_blocks if len(b) > 4 and len(b[4].strip()) > 10]),
                        'image_details': len(images),
                        'text_blocks_count': len(text_blocks),
                        'file_size_contribution': len(img_data)
                    }
                    
                    page_time = time.time() - page_start_time
                    
                    analysis = PageAnalysis(
                        page_num=i + 1,
                        doc_type=doc_type,
                        confidence=confidence,
                        metrics=metrics,
                        source=source_info,
                        issues=issues,
                        content_info=content_info,
                        processing_time=page_time
                    )
                    
                    results.append(analysis)
                    
                    if progress_callback:
                        progress_callback(i + 1, total_pages)
                    
                    print(f"✓ Page {i+1}/{total_pages} processed", end='\r')
                    
                except Exception as e:
                    print(f"❌ Error processing page {i+1}: {e}")
                    results.append(self._create_fallback_analysis(i, 'pdf'))
            
            doc.close()
            
            elapsed = time.time() - start_time
            print(f"\n🎯 PDF analysis completed in {elapsed:.2f}s")
            
            return results
            
        except Exception as e:
            print(f"❌ Error analyzing PDF: {e}")
            return [self._create_fallback_analysis(0, 'pdf')]
    
    def _detect_issues_with_thresholds(self, metrics: QualityMetrics, source: PageSourceInfo) -> List[str]:
        """Detect issues using configurable thresholds"""
        issues = []
        config = self.threshold_manager.config.get('quality_metrics', {})
        
        # Check each metric against its threshold
        if 'blur_score' in config:
            threshold = config['blur_score']['threshold']
            if metrics.blur_score < threshold:
                issues.append("blurry")
        
        if 'contrast_score' in config:
            threshold = config['contrast_score']['threshold']
            if metrics.contrast_score < threshold:
                issues.append("low_contrast")
        
        if 'noise_level' in config:
            threshold = config['noise_level']['threshold']
            if metrics.noise_level > threshold:
                issues.append("noisy")
        
        if 'sharpness_score' in config:
            threshold = config['sharpness_score']['threshold']
            if metrics.sharpness_score < threshold:
                issues.append("low_sharpness")
        
        if 'brightness_score' in config:
            # Special handling for brightness (optimal range)
            if metrics.brightness_score < 0.3:
                issues.append("too_dark")
            elif metrics.brightness_score > 0.8:
                issues.append("too_bright")
        
        if 'skew_angle' in config:
            threshold = config['skew_angle']['threshold']
            if abs(metrics.skew_angle) > threshold:
                issues.append(f"skewed_{metrics.skew_angle:.1f}°")
        
        if 'text_coverage' in config:
            threshold = config['text_coverage']['threshold']
            if metrics.text_coverage < threshold and source.source_type != 'text_document':
                issues.append("low_text_coverage")
        
        if 'ocr_confidence' in config:
            threshold = config['ocr_confidence']['threshold']
            if metrics.ocr_confidence < threshold:
                issues.append("low_ocr_confidence")
        
        if 'margin_safety' in config:
            threshold = config['margin_safety']['threshold']
            if metrics.margin_safety < threshold:
                issues.append("margin_issues")
        
        if 'duplicate_blank' in config:
            threshold = config['duplicate_blank']['threshold']
            if metrics.duplicate_blank_score < threshold:
                issues.append("duplicate_or_blank")
        
        if 'compression_artifacts' in config:
            threshold = config['compression_artifacts']['threshold']
            if metrics.compression_artifact_score < threshold:
                issues.append("compression_artifacts")
        
        if 'page_consistency' in config:
            threshold = config['page_consistency']['threshold']
            if metrics.page_consistency < threshold:
                issues.append("inconsistent_page")
        
        # Legacy checks for backward compatibility
        if min(metrics.resolution) < 300 and source.source_type != 'text_document':
            issues.append("low_resolution")
        if source.text_layer_type == 'none':
            issues.append("no_text_layer")
        
        return issues if issues else ["ok"]
    
    def _analyze_docx(self, file_path: str, progress_callback=None) -> List[PageAnalysis]:
        """Analyze DOCX files with comprehensive metrics"""
        print("📝 Analyzing DOCX document...")
        start_time = time.time()
        
        try:
            if not DOCX_AVAILABLE:
                raise ImportError("python-docx not available")
                
            doc = docx.Document(file_path)
            
            # Extract text content
            paragraphs = [p.text for p in doc.paragraphs]
            full_text = '\n'.join(paragraphs)
            
            # Enhanced text extraction with mammoth if available
            if MAMMOTH_AVAILABLE:
                try:
                    with open(file_path, "rb") as docx_file:
                        result = mammoth.extract_raw_text(docx_file)
                        enhanced_text = result.value
                        if len(enhanced_text) > len(full_text):
                            full_text = enhanced_text
                except:
                    pass
            
            # Analyze document structure
            word_count = len(full_text.split()) if full_text else 0
            char_count = len(full_text)
            paragraph_count = len([p for p in paragraphs if p.strip()])
            
            # Extract images and media
            images_info = []
            try:
                for rel in doc.part.rels.values():
                    if "image" in rel.target_ref:
                        images_info.append({
                            'name': rel.target_ref,
                            'type': 'embedded_image'
                        })
            except:
                pass
            
            # Create virtual metrics for text documents
            metrics = QualityMetrics(
                blur_score=100.0,
                resolution=(0, 0),
                skew_angle=0.0,
                contrast_score=1.0,
                noise_level=0.0,
                text_coverage=1.0 if word_count > 0 else 0.0,
                sharpness_score=100.0,
                brightness_score=0.5,
                ocr_confidence=1.0,
                margin_safety=1.0,
                duplicate_blank_score=1.0,
                compression_artifact_score=1.0,
                page_consistency=1.0
            )
            
            source_info = PageSourceInfo(
                source_type='text_document',
                has_images=len(images_info) > 0,
                text_layer_type='native',
                compression_detected=True,
                image_count=len(images_info)
            )
            
            # Determine quality based on content using thresholds
            if word_count > 100:
                doc_type = 'digital'
                confidence = 0.95
                issues = self._detect_issues_with_thresholds(metrics, source_info)
            elif word_count > 10:
                doc_type = 'digital'
                confidence = 0.8
                issues = ['minimal_content']
            else:
                doc_type = 'poor_scan'
                confidence = 0.3
                issues = ['no_content', 'empty_document']
            
            content_info = {
                'word_count': word_count,
                'char_count': char_count,
                'paragraph_count': paragraph_count,
                'image_count': len(images_info),
                'document_structure': {
                    'has_tables': len(doc.tables) > 0,
                    'style_count': len(doc.styles)
                },
                'file_info': {
                    'file_size': os.path.getsize(file_path)
                }
            }
            
            processing_time = time.time() - start_time
            
            analysis = PageAnalysis(
                page_num=1,
                doc_type=doc_type,
                confidence=confidence,
                metrics=metrics,
                source=source_info,
                issues=issues,
                content_info=content_info,
                processing_time=processing_time
            )
            
            print(f"✅ DOCX analysis completed in {processing_time:.2f}s")
            
            return [analysis]
            
        except Exception as e:
            print(f"❌ Error analyzing DOCX: {e}")
            return [self._create_fallback_analysis(0, 'docx')]
    
    def _analyze_xlsx(self, file_path: str, progress_callback=None) -> List[PageAnalysis]:
        """Analyze Excel files with comprehensive sheet-by-sheet metrics"""
        print("📊 Analyzing Excel spreadsheet...")
        start_time = time.time()
        
        try:
            if not EXCEL_AVAILABLE:
                raise ImportError("openpyxl/xlrd not available")
                
            excel_file = pd.ExcelFile(file_path)
            sheet_names = excel_file.sheet_names
            analyses = []
            
            # Store sheet hashes for duplicate detection
            sheet_hashes = []
            
            for i, sheet_name in enumerate(sheet_names):
                sheet_start_time = time.time()
                
                try:
                    # Read sheet
                    df = pd.read_excel(file_path, sheet_name=sheet_name)
                    
                    # Comprehensive sheet analysis
                    total_cells = df.shape[0] * df.shape[1]
                    non_null_cells = df.notna().sum().sum()
                    data_density = non_null_cells / total_cells if total_cells > 0 else 0
                    
                    # Data type analysis
                    numeric_columns = len(df.select_dtypes(include=[np.number]).columns)
                    text_columns = len(df.select_dtypes(include=['object']).columns)
                    
                    # Data quality metrics
                    duplicate_rows = df.duplicated().sum()
                    missing_data_ratio = df.isnull().sum().sum() / total_cells if total_cells > 0 else 0
                    
                    # Calculate new metrics
                    ocr_confidence = 1.0
                    margin_safety = 1.0
                    duplicate_blank_score = self._calculate_excel_duplicate_blank_score(df, sheet_hashes)
                    compression_artifact_score = 1.0
                    page_consistency = self._calculate_excel_page_consistency(i, analyses, df)
                    
                    # Create metrics for spreadsheet
                    metrics = QualityMetrics(
                        blur_score=100.0,
                        resolution=(df.shape[1], df.shape[0]),
                        skew_angle=0.0,
                        contrast_score=1.0,
                        noise_level=missing_data_ratio,
                        text_coverage=data_density,
                        sharpness_score=100.0,
                        brightness_score=0.5,
                        ocr_confidence=ocr_confidence,
                        margin_safety=margin_safety,
                        duplicate_blank_score=duplicate_blank_score,
                        compression_artifact_score=compression_artifact_score,
                        page_consistency=page_consistency
                    )
                    
                    # Update sheet hashes for duplicate detection
                    sheet_hash = hash(df.to_string())
                    sheet_hashes.append(sheet_hash)
                    
                    source_info = PageSourceInfo(
                        source_type='spreadsheet',
                        has_images=False,
                        text_layer_type='native',
                        compression_detected=True,
                        image_count=0
                    )
                    
                    # Quality assessment using thresholds
                    if data_density > 0.5 and df.shape[0] > 10 and missing_data_ratio < 0.2:
                        doc_type = 'digital'
                        confidence = 0.95
                        issues = self._detect_issues_with_thresholds(metrics, source_info)
                    elif data_density > 0.1 and df.shape[0] > 1:
                        doc_type = 'digital'
                        confidence = 0.7
                        issues = ['sparse_data'] if data_density < 0.3 else self._detect_issues_with_thresholds(metrics, source_info)
                    else:
                        doc_type = 'poor_scan'
                        confidence = 0.4
                        issues = ['empty_sheet', 'no_data']
                    
                    # Add issues based on data quality
                    if missing_data_ratio > 0.5:
                        issues.append('high_missing_data')
                    if duplicate_rows > df.shape[0] * 0.1:
                        issues.append('duplicate_data')
                    
                    content_info = {
                        'sheet_name': sheet_name,
                        'dimensions': {'rows': df.shape[0], 'columns': df.shape[1]},
                        'data_summary': {
                            'total_cells': total_cells,
                            'filled_cells': int(non_null_cells),
                            'data_density': data_density
                        },
                        'column_analysis': {
                            'numeric_columns': numeric_columns,
                            'text_columns': text_columns,
                            'total_columns': len(df.columns)
                        },
                        'data_quality': {
                            'duplicate_rows': int(duplicate_rows),
                            'missing_data_ratio': missing_data_ratio
                        }
                    }
                    
                    sheet_processing_time = time.time() - sheet_start_time
                    
                    analysis = PageAnalysis(
                        page_num=i + 1,
                        doc_type=doc_type,
                        confidence=confidence,
                        metrics=metrics,
                        source=source_info,
                        issues=issues,
                        content_info=content_info,
                        processing_time=sheet_processing_time
                    )
                    
                    analyses.append(analysis)
                    
                    if progress_callback:
                        progress_callback(i + 1, len(sheet_names))
                    
                    print(f"✓ Sheet {i+1}/{len(sheet_names)} '{sheet_name}' processed", end='\r')
                    
                except Exception as e:
                    print(f"❌ Error processing sheet '{sheet_name}': {e}")
                    analyses.append(self._create_fallback_analysis(i, 'xlsx'))
            
            elapsed = time.time() - start_time
            print(f"\n🎯 Excel analysis completed in {elapsed:.2f}s")
            
            return analyses
            
        except Exception as e:
            print(f"❌ Error analyzing Excel file: {e}")
            return [self._create_fallback_analysis(0, 'xlsx')]
    
    def _analyze_image(self, file_path: str, progress_callback=None) -> List[PageAnalysis]:
        """Analyze image files with comprehensive metrics"""
        file_ext = Path(file_path).suffix.lower()
        print(f"🖼️ Analyzing {file_ext.upper()} image...")
        start_time = time.time()
        
        try:
            # Load image
            img = cv2.imread(file_path)
            if img is None:
                pil_img = Image.open(file_path)
                img = cv2.cvtColor(np.array(pil_img), cv2.COLOR_RGB2BGR)
            
            # Convert to grayscale for analysis
            if len(img.shape) == 3:
                gray_img = cv2.cvtColor(img, cv2.COLOR_BGR2GRAY)
            else:
                gray_img = img
            
            # Comprehensive image quality analysis using JIT functions
            blur_score = float(fast_blur_detection(gray_img))
            contrast, noise = fast_contrast_noise(gray_img)
            sharpness, brightness = fast_sharpness_brightness(gray_img)
            skew_angle = self._fast_skew_detection(gray_img)
            
            # New metrics calculations
            ocr_confidence = 0.0
            margin_safety = self._calculate_image_margin_safety(gray_img)
            duplicate_blank_score = 1.0
            compression_artifact_score = self._calculate_compression_artifacts(gray_img)
            page_consistency = 1.0
            
            metrics = QualityMetrics(
                blur_score=blur_score,
                resolution=(img.shape[1], img.shape[0]),
                skew_angle=skew_angle,
                contrast_score=float(contrast),
                noise_level=float(noise),
                text_coverage=0.0,
                sharpness_score=float(sharpness),
                brightness_score=float(brightness),
                ocr_confidence=ocr_confidence,
                margin_safety=margin_safety,
                duplicate_blank_score=duplicate_blank_score,
                compression_artifact_score=compression_artifact_score,
                page_consistency=page_consistency
            )
            
            source_info = PageSourceInfo(
                source_type='image_file',
                has_images=True,
                text_layer_type='none',
                compression_detected=self._detect_compression(file_path),
                image_count=1
            )
            
            # Image quality classification using thresholds
            doc_type, confidence = self._classify_image_quality_with_thresholds(metrics, source_info)
            
            # Issue detection using thresholds
            issues = self._detect_issues_with_thresholds(metrics, source_info)
            
            content_info = {
                'image_properties': {
                    'format': file_ext.upper().replace('.', ''),
                    'mode': 'Color' if len(img.shape) == 3 else 'Grayscale',
                    'channels': img.shape[2] if len(img.shape) == 3 else 1,
                    'file_size': os.path.getsize(file_path)
                },
                'quality_assessment': {
                    'estimated_dpi': self._estimate_dpi(img.shape),
                    'compression_detected': self._detect_compression(file_path),
                    'likely_document': blur_score > 50 and contrast > 0.2
                }
            }
            
            processing_time = time.time() - start_time
            
            analysis = PageAnalysis(
                page_num=1,
                doc_type=doc_type,
                confidence=confidence,
                metrics=metrics,
                source=source_info,
                issues=issues,
                content_info=content_info,
                processing_time=processing_time
            )
            
            print(f"✅ Image analysis completed in {processing_time:.2f}s")
            
            return [analysis]
            
        except Exception as e:
            print(f"❌ Error analyzing image: {e}")
            return [self._create_fallback_analysis(0, 'image')]

    def _classify_image_quality_with_thresholds(self, metrics: QualityMetrics, source: PageSourceInfo) -> Tuple[str, float]:
        """Classify image quality using configurable thresholds"""
        config = self.threshold_manager.config.get('quality_metrics', {})
        score = 0.0
        
        # Evaluate against configurable thresholds
        blur_threshold = config.get('blur_score', {}).get('threshold', 80)
        if metrics.blur_score > blur_threshold * 1.25:
            score += 0.25
        elif metrics.blur_score > blur_threshold:
            score += 0.15
        
        contrast_threshold = config.get('contrast_score', {}).get('threshold', 0.2)
        if metrics.contrast_score > contrast_threshold * 1.25:
            score += 0.25
        elif metrics.contrast_score > contrast_threshold:
            score += 0.15
        
        noise_threshold = config.get('noise_level', {}).get('threshold', 0.25)
        if metrics.noise_level < noise_threshold * 0.6:
            score += 0.15
        
        sharpness_threshold = config.get('sharpness_score', {}).get('threshold', 30)
        if metrics.sharpness_score > sharpness_threshold * 1.3:
            score += 0.2
        elif metrics.sharpness_score > sharpness_threshold:
            score += 0.1
        
        # Brightness optimal range
        if 0.3 < metrics.brightness_score < 0.8:
            score += 0.15
        
        # New metrics scoring
        ocr_threshold = config.get('ocr_confidence', {}).get('threshold', 0.7)
        if metrics.ocr_confidence > ocr_threshold:
            score += 0.1
        
        margin_threshold = config.get('margin_safety', {}).get('threshold', 0.9)
        if metrics.margin_safety > margin_threshold:
            score += 0.05
        
        compression_threshold = config.get('compression_artifacts', {}).get('threshold', 0.7)
        if metrics.compression_artifact_score > compression_threshold:
            score += 0.05
        
        if score >= 0.6:
            return 'digital', min(score, 1.0)
        elif score >= 0.3:
            return 'good_scan', min(score, 0.9)
        else:
            return 'poor_scan', min(score, 0.8)
    
    def _calculate_ocr_confidence(self, text_content: str, text_blocks: List) -> float:
        """Calculate OCR confidence (simplified heuristic based on text quality)"""
        if not text_content or not text_blocks:
            return 0.0
        special_chars = sum(1 for c in text_content if ord(c) > 127)
        text_len = len(text_content)
        ocr_ratio = special_chars / text_len if text_len > 0 else 0
        confidence = 1.0 if ocr_ratio < 0.02 else 0.6
        return min(confidence, 1.0)
    
    def _calculate_margin_safety(self, text_blocks: List, img_shape: Tuple) -> float:
        """Calculate margin safety to detect cropping issues"""
        if not text_blocks:
            return 1.0
        h, w = img_shape
        margin_threshold = 0.05 * min(h, w)
        for block in text_blocks:
            if len(block) >= 4:
                x0, y0, x1, y1 = block[:4]
                if x0 < margin_threshold or y0 < margin_threshold or \
                   (w - x1) < margin_threshold or (h - y1) < margin_threshold:
                    return 0.5
        return 1.0
    
    def _calculate_duplicate_blank_score(self, gray_img: np.ndarray, page_hashes: List) -> float:
        """Calculate duplicate/blank page score"""
        if np.std(gray_img) < 5.0:
            return 0.0
        current_hash = hash(gray_img.tobytes())
        if current_hash in page_hashes:
            return 0.0
        return 1.0
    
    def _calculate_compression_artifacts(self, gray_img: np.ndarray) -> float:
        """Calculate compression artifact score"""
        noise_level = fast_contrast_noise(gray_img)[1]
        return 1.0 - noise_level
    
    def _calculate_page_consistency(self, page_idx: int, previous_results: List[PageAnalysis], img_shape: Tuple) -> float:
        """Calculate page consistency compared to previous pages"""
        if page_idx == 0 or not previous_results:
            return 1.0
        prev_result = previous_results[-1]
        prev_resolution = prev_result.metrics.resolution
        current_resolution = img_shape[::-1]
        resolution_match = min(current_resolution[0] / prev_resolution[0], prev_resolution[0] / current_resolution[0]) if prev_resolution[0] > 0 else 1.0
        return min(resolution_match, 1.0)
    
    def _calculate_excel_duplicate_blank_score(self, df: pd.DataFrame, sheet_hashes: List) -> float:
        """Calculate duplicate/blank score for Excel sheets"""
        if df.empty or df.notna().sum().sum() == 0:
            return 0.0
        current_hash = hash(df.to_string())
        if current_hash in sheet_hashes:
            return 0.0
        return 1.0
    
    def _calculate_excel_page_consistency(self, sheet_idx: int, previous_analyses: List[PageAnalysis], df: pd.DataFrame) -> float:
        """Calculate page consistency for Excel sheets"""
        if sheet_idx == 0 or not previous_analyses:
            return 1.0
        prev_analysis = previous_analyses[-1]
        prev_dims = prev_analysis.content_info.get('dimensions', {})
        current_dims = {'rows': df.shape[0], 'columns': df.shape[1]}
        row_match = min(current_dims['rows'] / prev_dims.get('rows', 1), prev_dims.get('rows', 1) / current_dims['rows']) if prev_dims.get('rows', 0) > 0 else 1.0
        col_match = min(current_dims['columns'] / prev_dims.get('columns', 1), prev_dims.get('columns', 1) / current_dims['columns']) if prev_dims.get('columns', 0) > 0 else 1.0
        return min(row_match, col_match, 1.0)
    
    def _calculate_image_margin_safety(self, gray_img: np.ndarray) -> float:
        """Calculate margin safety for images"""
        h, w = gray_img.shape
        margin_threshold = 0.05 * min(h, w)
        border_pixels = np.concatenate([
            gray_img[:int(margin_threshold), :].flatten(),
            gray_img[-int(margin_threshold):, :].flatten(),
            gray_img[:, :int(margin_threshold)].flatten(),
            gray_img[:, -int(margin_threshold):].flatten()
        ])
        if np.mean(border_pixels) < 240:
            return 0.5
        return 1.0
    
    def _fast_skew_detection(self, gray_img: np.ndarray) -> float:
        """Ultra-fast skew detection"""
        try:
            h, w = gray_img.shape
            sample_h = min(h // 3, 200)
            sample_w = min(w // 3, 300)
            start_h = (h - sample_h) // 2
            start_w = (w - sample_w) // 2
            
            sample = gray_img[start_h:start_h+sample_h, start_w:start_w+sample_w]
            edges = cv2.Canny(sample, 50, 150, apertureSize=3)
            lines = cv2.HoughLines(edges, 1, np.pi/180, threshold=max(20, sample_h//10))
            
            if lines is not None and len(lines) > 0:
                angles = []
                for line in lines[:10]:
                    rho, theta = line[0]
                    angle = np.degrees(theta) - 90
                    if -45 < angle < 45:
                        angles.append(angle)
                if angles:
                    return float(np.median(angles))
        except:
            pass
        return 0.0
    
    def _fast_text_coverage(self, text_blocks: List, img_shape: Tuple) -> float:
        """Calculate text coverage"""
        if not text_blocks:
            return 0.0
        
        total_area = img_shape[0] * img_shape[1]
        text_area = 0
        
        for block in text_blocks:
            if len(block) >= 5:
                x0, y0, x1, y1 = block[:4]
                text_area += max(0, (x1 - x0) * (y1 - y0))
        
        return min(text_area / total_area, 1.0)
    
    def _analyze_pdf_page_source(self, text_content: str, images: List) -> PageSourceInfo:
        """Analyze PDF page source"""
        has_images = len(images) > 0
        image_count = len(images)
        text_len = len(text_content.strip())
        
        if text_len == 0:
            text_layer = 'none'
        elif text_len < 50 and has_images:
            text_layer = 'ocr'
        else:
            special_chars = sum(1 for c in text_content if ord(c) > 127)
            ocr_ratio = special_chars / text_len if text_len > 0 else 0
            text_layer = 'ocr' if ocr_ratio > 0.02 else 'native'
        
        if not has_images and text_len > 100:
            source_type = 'native_pdf'
        elif has_images and image_count == 1 and text_len < 100:
            source_type = 'image_scan'
        else:
            source_type = 'hybrid'
        
        return PageSourceInfo(
            source_type=source_type,
            has_images=has_images,
            text_layer_type=text_layer,
            compression_detected=image_count > 0,
            image_count=image_count
        )
    
    def _classify_document_quality(self, metrics: QualityMetrics, source: PageSourceInfo) -> Tuple[str, float]:
        """Classify document quality using configurable thresholds"""
        config = self.threshold_manager.config.get('quality_metrics', {})
        score = 0.0
        
        # Source type scoring
        if source.source_type == 'native_pdf' or source.source_type == 'text_document':
            score += 0.4
        elif source.text_layer_type == 'native':
            score += 0.35
        elif source.has_images and source.text_layer_type in ['native', 'ocr']:
            score += 0.2
        
        # Quality metrics scoring using configurable thresholds
        blur_config = config.get('blur_score', {})
        blur_threshold = blur_config.get('threshold', 80)
        if metrics.blur_score > blur_threshold * 1.5:
            score += 0.2
        elif metrics.blur_score > blur_threshold:
            score += 0.1
        
        contrast_config = config.get('contrast_score', {})
        contrast_threshold = contrast_config.get('threshold', 0.2)
        if metrics.contrast_score > contrast_threshold * 1.5:
            score += 0.15
        elif metrics.contrast_score > contrast_threshold:
            score += 0.08
        
        noise_config = config.get('noise_level', {})
        noise_threshold = noise_config.get('threshold', 0.25)
        if metrics.noise_level < noise_threshold * 0.4:
            score += 0.1
        elif metrics.noise_level < noise_threshold:
            score += 0.05
        
        skew_config = config.get('skew_angle', {})
        skew_threshold = skew_config.get('threshold', 2)
        if abs(metrics.skew_angle) < skew_threshold * 0.5:
            score += 0.1
        elif abs(metrics.skew_angle) < skew_threshold:
            score += 0.05
        
        # New metrics scoring
        ocr_threshold = config.get('ocr_confidence', {}).get('threshold', 0.7)
        if metrics.ocr_confidence > ocr_threshold:
            score += 0.1
        
        margin_threshold = config.get('margin_safety', {}).get('threshold', 0.9)
        if metrics.margin_safety > margin_threshold:
            score += 0.05
        
        duplicate_threshold = config.get('duplicate_blank', {}).get('threshold', 0.9)
        if metrics.duplicate_blank_score > duplicate_threshold:
            score += 0.05
        
        compression_threshold = config.get('compression_artifacts', {}).get('threshold', 0.7)
        if metrics.compression_artifact_score > compression_threshold:
            score += 0.05
        
        consistency_threshold = config.get('page_consistency', {}).get('threshold', 0.9)
        if metrics.page_consistency > consistency_threshold:
            score += 0.05
        
        if score >= 0.7:
            return 'digital', min(score, 1.0)
        elif score >= 0.4:
            return 'good_scan', min(score, 0.9)
        else:
            return 'poor_scan', min(score, 0.8)
    
    def _detect_compression(self, file_path: str) -> bool:
        """Simple compression detection based on file format"""
        ext = Path(file_path).suffix.lower()
        return ext in ['.jpg', '.jpeg', '.pdf', '.docx', '.xlsx']
    
    def _estimate_dpi(self, shape: Tuple) -> int:
        """Estimate DPI based on image dimensions"""
        width, height = shape[1], shape[0]
        
        if width > 2400 or height > 3200:
            return 300
        elif width > 1600 or height > 2100:
            return 200
        elif width > 800 or height > 1000:
            return 150
        else:
            return 96
    
    def _create_fallback_analysis(self, page_num: int, doc_type: str) -> PageAnalysis:
        """Create fallback analysis for failed pages"""
        fallback_metrics = QualityMetrics(
            blur_score=0.0,
            resolution=(0, 0),
            skew_angle=0.0,
            contrast_score=0.0,
            noise_level=0.0,
            text_coverage=0.0,
            sharpness_score=0.0,
            brightness_score=0.0,
            ocr_confidence=0.0,
            margin_safety=0.0,
            duplicate_blank_score=0.0,
            compression_artifact_score=0.0,
            page_consistency=0.0
        )
        
        fallback_source = PageSourceInfo(
            source_type='unknown',
            has_images=False,
            text_layer_type='none',
            compression_detected=False,
            image_count=0
        )
        
        return PageAnalysis(
            page_num=page_num + 1,
            doc_type='poor_scan',
            confidence=0.0,
            metrics=fallback_metrics,
            source=fallback_source,
            issues=['processing_failed'],
            content_info={'error': 'Failed to process'},
            processing_time=0.0
        )

class UniversalDocumentPrinter:
    """
    Comprehensive printer for all document analysis results
    Extended to handle configurable thresholds and verdicts
    """
    
    def __init__(self, analyzer_results: List[PageAnalysis], file_path: str):
        self.results = analyzer_results
        self.total_pages = len(analyzer_results)
        self.file_path = Path(file_path)
        self.file_type = self._determine_file_type()
    
    def _determine_file_type(self) -> str:
        """Determine the file type for display purposes"""
        ext = self.file_path.suffix.lower()
        type_map = {
            '.pdf': 'PDF Document',
            '.docx': 'Word Document',
            '.xlsx': 'Excel Spreadsheet',
            '.xls': 'Excel Spreadsheet',
            '.jpg': 'JPEG Image',
            '.jpeg': 'JPEG Image',
            '.png': 'PNG Image',
            '.bmp': 'BMP Image',
            '.tiff': 'TIFF Image',
            '.tif': 'TIFF Image'
        }
        return type_map.get(ext, 'Unknown Document')
    
    def print_everything(self, show_recommendations: bool = True, 
                        show_statistics: bool = True,
                        show_quality_flags: bool = True):
        """
        Print EVERYTHING - complete analysis for all document types
        """
        print("\n" + "="*100)
        print("UNIVERSAL DOCUMENT ANALYSIS - COMPLETE DATA DUMP")
        print("="*100)
        print(f"Analysis Date: {datetime.now().strftime('%Y-%m-%d %H:%M:%S')}")
        print(f"Document: {self.file_path.name}")
        print(f"File Type: {self.file_type}")
        print(f"Total Pages/Sheets: {self.total_pages}")
        print(f"File Size: {self._format_file_size(os.path.getsize(self.file_path))}")
        print(f"Analysis Level: COMPLETE - Every page/sheet, every metric")
        print("="*100)
        
        # 1. EXECUTIVE SUMMARY
        self._print_executive_summary()
        
        # 2. DETAILED PAGE-BY-PAGE ANALYSIS
        self._print_detailed_pages(show_recommendations, show_quality_flags)
        
        # 3. STATISTICAL ANALYSIS
        if show_statistics:
            self._print_statistical_analysis()
        
        # 4. ISSUE BREAKDOWN
        self._print_issue_breakdown()
        
        # 5. PROCESSING RECOMMENDATIONS SUMMARY
        if show_recommendations:
            self._print_processing_summary()
        
        # 6. DATA TABLES
        self._print_data_tables()
        
        # 7. DOCUMENT-SPECIFIC ANALYSIS
        self._print_document_specific_analysis()
        
        # 8. VERDICT SUMMARY (New section)
        self._print_verdict_summary()
        
        print("\n" + "="*100)
        print("COMPREHENSIVE ANALYSIS COMPLETE")
        print("="*100)
    
    def _format_file_size(self, size_bytes: int) -> str:
        """Format file size in human readable format"""
        if size_bytes == 0:
            return "0 B"
        size_names = ["B", "KB", "MB", "GB"]
        i = int(np.floor(np.log(size_bytes) / np.log(1024)))
        p = pow(1024, i)
        s = round(size_bytes / p, 2)
        return f"{s} {size_names[i]}"
    
    def _print_executive_summary(self):
        """Print high-level summary adapted for all document types"""
        print(f"\nEXECUTIVE SUMMARY")
        print("-" * 50)
        
        # Count by type
        digital = sum(1 for r in self.results if r.doc_type == 'digital')
        good_scan = sum(1 for r in self.results if r.doc_type == 'good_scan')
        poor_scan = sum(1 for r in self.results if r.doc_type == 'poor_scan')
        
        # Overall quality score
        quality_weights = {'digital': 1.0, 'good_scan': 0.7, 'poor_scan': 0.3}
        quality_score = sum(quality_weights[r.doc_type] for r in self.results) / self.total_pages
        
        # Assessment
        if quality_score >= 0.85:
            assessment = "EXCELLENT"
        elif quality_score >= 0.65:
            assessment = "GOOD"
        elif quality_score >= 0.45:
            assessment = "FAIR"
        else:
            assessment = "POOR"
        
        print(f"Overall Assessment: {assessment}")
        print(f"Quality Score: {quality_score:.3f}/1.000")
        print(f"Average Confidence: {sum(r.confidence for r in self.results)/self.total_pages:.3f}")
        
        # Document type specific breakdown
        page_label = "Pages" if self.file_type == "PDF Document" else "Sheets" if "Excel" in self.file_type else "Items"
        
        print(f"{self.file_type} Breakdown:")
        print(f"   • Digital {page_label}: {digital:3d} ({digital/self.total_pages*100:5.1f}%)")
        print(f"   • Good Scans:    {good_scan:3d} ({good_scan/self.total_pages*100:5.1f}%)")
        print(f"   • Poor Scans:    {poor_scan:3d} ({poor_scan/self.total_pages*100:5.1f}%)")
        
        # Content Analysis
        total_content = sum(r.content_info.get('word_count', 0) if r.content_info else 0 for r in self.results)
        if total_content > 0:
            print(f"Content Analysis:")
            print(f"   • Total Words: {total_content:,}")
            print(f"   • Average Words per {page_label[:-1]}: {total_content/self.total_pages:.1f}")
        
        # OCR Analysis (for visual documents)
        visual_pages = [r for r in self.results if r.source.source_type in ['image_scan', 'image_file', 'hybrid']]
        if visual_pages:
            needs_ocr = sum(1 for r in visual_pages if r.source.text_layer_type in ['none', 'ocr'])
            print(f"OCR Analysis:")
            print(f"   • Visual {page_label} Needing OCR: {needs_ocr:3d} ({needs_ocr/len(visual_pages)*100:5.1f}%)")
        
        # Processing time
        total_time = sum(r.processing_time for r in self.results)
        print(f"Processing Performance:")
        print(f"   • Total Processing Time: {total_time:.2f}s")
        print(f"   • Average Time per {page_label[:-1]}: {total_time/self.total_pages:.3f}s")
        
        # New: Average Overall Score from Verdicts
        avg_overall_score = np.mean([r.document_verdict.overall_score for r in self.results if r.document_verdict])
        print(f"Average Overall Verdict Score: {avg_overall_score:.3f}")
    
    def _print_detailed_pages(self, show_recommendations: bool, show_quality_flags: bool):
        """Print detailed analysis for every page/sheet"""
        page_label = "PAGE" if self.file_type == "PDF Document" else "SHEET" if "Excel" in self.file_type else "ITEM"
        
        print(f"\nDETAILED {page_label}-BY-{page_label} ANALYSIS")
        print("-" * 80)
        print("Legend: EXCELLENT | GOOD | ACCEPTABLE | POOR")
        print("-" * 80)
        
        for i, result in enumerate(self.results):
            # Quality indicator from doc_type
            if result.doc_type == 'digital':
                quality_icon = "EXCELLENT"
            elif result.doc_type == 'good_scan':
                quality_icon = "GOOD"
            else:
                quality_icon = "POOR"
            
            # Page/Sheet specific header
            if "Excel" in self.file_type and result.content_info:
                sheet_name = result.content_info.get('sheet_name', f'Sheet{result.page_num}')
                header = f"{quality_icon} {page_label} {result.page_num:3d} - {sheet_name} - {result.doc_type.upper().replace('_', ' ')}"
            else:
                header = f"{quality_icon} {page_label} {result.page_num:3d} - {result.doc_type.upper().replace('_', ' ')}"
            
            print(f"\n{header}")
            print(f"{'─' * 60}")
            
            # Basic Info
            print(f"Confidence Score: {result.confidence:.3f}")
            print(f"Processing Time: {result.processing_time:.3f}s")
            
            # Document type specific info
            if result.source.source_type == 'text_document':
                print(f"Document Type: Text Document (DOCX)")
                print(f"Embedded Images: {result.source.image_count}")
                if result.content_info:
                    print(f"Word Count: {result.content_info.get('word_count', 0):,}")
                    print(f"Paragraphs: {result.content_info.get('paragraph_count', 0)}")
                    
            elif result.source.source_type == 'spreadsheet':
                print(f"Document Type: Spreadsheet")
                if result.content_info:
                    dims = result.content_info.get('dimensions', {})
                    print(f"Dimensions: {dims.get('rows', 0)} rows × {dims.get('columns', 0)} columns")
                    data_summary = result.content_info.get('data_summary', {})
                    print(f"Data Density: {data_summary.get('data_density', 0):.1%}")
                    print(f"Filled Cells: {data_summary.get('filled_cells', 0):,}")
                    
            else:
                # Visual document (PDF, images)
                print(f"Resolution: {result.metrics.resolution[0]} x {result.metrics.resolution[1]} px")
                print(f"Source Type: {result.source.source_type.replace('_', ' ').title()}")
                print(f"Text Layer: {result.source.text_layer_type.title()}")
                print(f"Images: {result.source.image_count} detected")
                
                # Quality Metrics (only for visual content)
                print(f"\nQUALITY METRICS:")
                print(f"   • Blur Score:     {result.metrics.blur_score:7.1f} {'OK' if result.metrics.blur_score > 80 else 'LOW' if result.metrics.blur_score > 50 else 'BAD'}")
                print(f"   • Contrast:       {result.metrics.contrast_score:7.3f} {'OK' if result.metrics.contrast_score > 0.2 else 'LOW' if result.metrics.contrast_score > 0.1 else 'BAD'}")
                print(f"   • Noise Level:    {result.metrics.noise_level:7.3f} {'OK' if result.metrics.noise_level < 0.2 else 'HIGH' if result.metrics.noise_level < 0.3 else 'BAD'}")
                print(f"   • Sharpness:      {result.metrics.sharpness_score:7.1f} {'OK' if result.metrics.sharpness_score > 30 else 'LOW' if result.metrics.sharpness_score > 15 else 'BAD'}")
                print(f"   • Brightness:     {result.metrics.brightness_score:7.3f} {'OK' if 0.3 < result.metrics.brightness_score < 0.8 else 'POOR'}")
                print(f"   • Skew Angle:     {result.metrics.skew_angle:7.1f}° {'OK' if abs(result.metrics.skew_angle) < 1 else 'TILTED' if abs(result.metrics.skew_angle) < 3 else 'BAD'}")
                print(f"   • Text Coverage:  {result.metrics.text_coverage:7.3f} {'OK' if result.metrics.text_coverage > 0.1 else 'LOW'}")
                print(f"   • OCR Confidence: {result.metrics.ocr_confidence:7.3f} {'OK' if result.metrics.ocr_confidence > 0.7 else 'BAD'}")
                print(f"   • Margin Safety:  {result.metrics.margin_safety:7.3f} {'OK' if result.metrics.margin_safety > 0.9 else 'BAD'}")
                print(f"   • Duplicate/Blank: {result.metrics.duplicate_blank_score:7.3f} {'OK' if result.metrics.duplicate_blank_score > 0.9 else 'BAD'}")
                print(f"   • Compression:    {result.metrics.compression_artifact_score:7.3f} {'OK' if result.metrics.compression_artifact_score > 0.7 else 'BAD'}")
                print(f"   • Consistency:    {result.metrics.page_consistency:7.3f} {'OK' if result.metrics.page_consistency > 0.9 else 'BAD'}")
            
            # Issues
            issue_str = ", ".join(result.issues) if result.issues != ['ok'] else "None"
            print(f"Issues: {issue_str}")
            
            # Quality Flags
            if show_quality_flags:
                flags = self._get_quality_flags(result)
                print(f"Quality Flags:")
                flag_items = []
                
                if flags.get('needs_ocr'): flag_items.append("OCR Needed")
                if flags.get('is_blurry'): flag_items.append("Blurry")
                if flags.get('is_skewed'): flag_items.append("Skewed")
                if flags.get('is_noisy'): flag_items.append("Noisy")
                if flags.get('low_contrast'): flag_items.append("Low Contrast")
                if flags.get('brightness_issues'): flag_items.append("Brightness Issues")
                if flags.get('low_resolution'): flag_items.append("Low Resolution")
                if flags.get('high_quality'): flag_items.append("High Quality")
                if flags.get('empty_content'): flag_items.append("Empty Content")
                if flags.get('sparse_data'): flag_items.append("Sparse Data")
                if flags.get('low_ocr_confidence'): flag_items.append("Low OCR Confidence")
                if flags.get('margin_issues'): flag_items.append("Margin Issues")
                if flags.get('duplicate_or_blank'): flag_items.append("Duplicate/Blank")
                if flags.get('compression_artifacts'): flag_items.append("Compression Artifacts")
                if flags.get('inconsistent_page'): flag_items.append("Inconsistent Page")
                
                if flag_items:
                    print(f"   {' | '.join(flag_items)}")
                else:
                    print(f"   No issues detected")
            
            # New: Print Verdict for the page
            if result.document_verdict:
                verdict = result.document_verdict
                print(f"\nVERDICT:")
                print(f"   • Overall Score: {verdict.overall_score:.3f}")
                print(f"   • Quality Level: {verdict.quality_level.upper()}")
                print(f"   • Action: {verdict.action.replace('_', ' ').title()}")
                print(f"   • Message: {verdict.message}")
                if verdict.critical_issues:
                    print(f"   • Critical Issues: {', '.join(verdict.critical_issues)}")
            
            # Processing Recommendations
            if show_recommendations:
                recommendations = self._get_processing_recommendations(result)
                if recommendations and recommendations != ['no_action_needed']:
                    print(f"Recommendations: {', '.join([r.replace('_', ' ').title() for r in recommendations])}")
                else:
                    print(f"Recommendations: No processing needed")
    
    def _get_quality_flags(self, page_result: PageAnalysis) -> Dict[str, bool]:
        """Generate quality flags for a page/sheet"""
        flags = {
            'needs_ocr': page_result.source.text_layer_type in ['none', 'ocr'],
            'high_quality': (page_result.doc_type == 'digital' and page_result.confidence > 0.8),
            'is_blurry': page_result.metrics.blur_score < 80,
            'is_skewed': abs(page_result.metrics.skew_angle) > 2.0,
            'is_noisy': page_result.metrics.noise_level > 0.25,
            'low_contrast': page_result.metrics.contrast_score < 0.15,
            'brightness_issues': page_result.metrics.brightness_score < 0.2 or page_result.metrics.brightness_score > 0.85,
            'low_resolution': min(page_result.metrics.resolution) < 300 if page_result.metrics.resolution != (0, 0) else False,
            'empty_content': page_result.content_info and page_result.content_info.get('word_count', 0) == 0,
            'sparse_data': page_result.source.source_type == 'spreadsheet' and page_result.metrics.text_coverage < 0.3,
            'low_ocr_confidence': page_result.metrics.ocr_confidence < 0.7,
            'margin_issues': page_result.metrics.margin_safety < 0.9,
            'duplicate_or_blank': page_result.metrics.duplicate_blank_score == 0.0,
            'compression_artifacts': page_result.metrics.compression_artifact_score < 0.7,
            'inconsistent_page': page_result.metrics.page_consistency < 0.9
        }
        return flags
    
    def _get_processing_recommendations(self, page_result: PageAnalysis) -> List[str]:
        """Generate processing recommendations"""
        recommendations = []
        
        if page_result.source.text_layer_type == 'none':
            recommendations.append('ocr_required')
        elif page_result.source.text_layer_type == 'ocr':
            recommendations.append('verify_ocr_quality')
        
        if page_result.metrics.blur_score < 50:
            recommendations.append('image_enhancement')
        elif page_result.metrics.blur_score < 80:
            recommendations.append('sharpening')
        
        if abs(page_result.metrics.skew_angle) > 2.0:
            recommendations.append('deskew')
        
        if page_result.metrics.contrast_score < 0.15:
            recommendations.append('contrast_adjustment')
        
        if page_result.metrics.noise_level > 0.3:
            recommendations.append('noise_reduction')
        
        if page_result.metrics.brightness_score < 0.2:
            recommendations.append('brighten')
        elif page_result.metrics.brightness_score > 0.85:
            recommendations.append('darken')
        
        if min(page_result.metrics.resolution) < 200 and page_result.metrics.resolution != (0, 0):
            recommendations.append('upscale')
        
        # New recommendations
        if page_result.metrics.ocr_confidence < 0.7:
            recommendations.append('improve_ocr')
        if page_result.metrics.margin_safety < 0.9:
            recommendations.append('adjust_margins')
        if page_result.metrics.duplicate_blank_score == 0.0:
            recommendations.append('remove_duplicate_blank')
        if page_result.metrics.compression_artifact_score < 0.7:
            recommendations.append('reduce_compression')
        if page_result.metrics.page_consistency < 0.9:
            recommendations.append('standardize_pages')
        
        return recommendations if recommendations else ['no_action_needed']
    
    def _print_statistical_analysis(self):
        """Print comprehensive statistical analysis for all document types"""
        print(f"\nSTATISTICAL ANALYSIS")
        print("-" * 50)
        
        # Only analyze visual metrics for documents that have them
        visual_results = [r for r in self.results if r.source.source_type in ['native_pdf', 'image_scan', 'hybrid', 'image_file']]
        
        if visual_results:
            print("VISUAL QUALITY METRICS:")
            
            # Extract visual metrics
            blur_scores = [r.metrics.blur_score for r in visual_results]
            contrast_scores = [r.metrics.contrast_score for r in visual_results]
            noise_levels = [r.metrics.noise_level for r in visual_results]
            sharpness_scores = [r.metrics.sharpness_score for r in visual_results]
            brightness_scores = [r.metrics.brightness_score for r in visual_results]
            skew_angles = [abs(r.metrics.skew_angle) for r in visual_results]
            text_coverage = [r.metrics.text_coverage for r in visual_results]
            ocr_confidences = [r.metrics.ocr_confidence for r in visual_results]
            margin_safeties = [r.metrics.margin_safety for r in visual_results]
            duplicate_blank_scores = [r.metrics.duplicate_blank_score for r in visual_results]
            compression_artifact_scores = [r.metrics.compression_artifact_score for r in visual_results]
            page_consistencies = [r.metrics.page_consistency for r in visual_results]
            
            metrics_data = [
                ("Blur Score", blur_scores, "higher is better", 80),
                ("Contrast Score", contrast_scores, "higher is better", 0.2),
                ("Noise Level", noise_levels, "lower is better", 0.25),
                ("Sharpness Score", sharpness_scores, "higher is better", 30),
                ("Brightness Score", brightness_scores, "0.3-0.8 optimal", 0.5),
                ("Skew Angle (abs)", skew_angles, "lower is better", 2),
                ("Text Coverage", text_coverage, "varies by document", 0.1),
                ("OCR Confidence", ocr_confidences, "higher is better", 0.7),
                ("Margin Safety", margin_safeties, "higher is better", 0.9),
                ("Duplicate/Blank", duplicate_blank_scores, "higher is better", 0.9),
                ("Compression", compression_artifact_scores, "higher is better", 0.7),
                ("Page Consistency", page_consistencies, "higher is better", 0.9)
            ]
            
            print(f"{'Metric':<20} {'Mean':<8} {'Std':<8} {'Min':<8} {'Max':<8} {'Median':<8} {'Quality':<10}")
            print("-" * 80)
            
            for name, values, desc, threshold in metrics_data:
                if values:  # Only if we have data
                    mean_val = np.mean(values)
                    std_val = np.std(values)
                    min_val = np.min(values)
                    max_val = np.max(values)
                    median_val = np.median(values)
                    
                    # Quality assessment
                    if "higher is better" in desc:
                        quality = "Good" if mean_val > threshold else "Poor"
                    elif "lower is better" in desc:
                        quality = "Good" if mean_val < threshold else "Poor"
                    else:
                        quality = "Variable"
                    
                    print(f"{name:<20} {mean_val:<8.3f} {std_val:<8.3f} {min_val:<8.3f} {max_val:<8.3f} {median_val:<8.3f} {quality:<10}")
        
        # Content statistics
        content_results = [r for r in self.results if r.content_info and r.content_info.get('word_count', 0) > 0]
        if content_results:
            print(f"\nCONTENT STATISTICS:")
            word_counts = [r.content_info['word_count'] for r in content_results]
            char_counts = [r.content_info.get('char_count', 0) for r in content_results]
            
            print(f"Word Count Statistics:")
            print(f"   • Total Words: {sum(word_counts):,}")
            print(f"   • Average: {np.mean(word_counts):.1f}")
            print(f"   • Median: {np.median(word_counts):.1f}")
            print(f"   • Range: {min(word_counts)} - {max(word_counts)}")
        
        # Overall confidence statistics
        confidence_scores = [r.confidence for r in self.results]
        print(f"\nCONFIDENCE STATISTICS:")
        print(f"   • Average Confidence: {np.mean(confidence_scores):.3f}")
        print(f"   • Median Confidence: {np.median(confidence_scores):.3f}")
        print(f"   • Confidence Range: {min(confidence_scores):.3f} - {max(confidence_scores):.3f}")
        print(f"   • Standard Deviation: {np.std(confidence_scores):.3f}")
        
        # New: Verdict Statistics
        if any(r.document_verdict for r in self.results):
            print(f"\nVERDICT STATISTICS:")
            overall_scores = [r.document_verdict.overall_score for r in self.results if r.document_verdict]
            print(f"   • Average Overall Score: {np.mean(overall_scores):.3f}")
            print(f"   • Median Overall Score: {np.median(overall_scores):.3f}")
            print(f"   • Score Range: {min(overall_scores):.3f} - {max(overall_scores):.3f}")
    
    def _print_issue_breakdown(self):
        """Print comprehensive issue breakdown"""
        print(f"\nISSUE BREAKDOWN")
        print("-" * 50)
        
        # Collect all issues
        all_issues = []
        for result in self.results:
            all_issues.extend(result.issues)
        
        # Count issues
        issue_counts = {}
        for issue in all_issues:
            if issue != 'ok':
                issue_counts[issue] = issue_counts.get(issue, 0) + 1
        
        if issue_counts:
            # Sort by frequency
            sorted_issues = sorted(issue_counts.items(), key=lambda x: x[1], reverse=True)
            
            print("Most Common Issues:")
            for issue, count in sorted_issues:
                percentage = count / self.total_pages * 100
                issue_display = issue.replace('_', ' ').title()
                print(f"   • {issue_display}: {count} pages ({percentage:.1f}%)")
        else:
            print("No issues detected in any pages!")
    
    def _print_processing_summary(self):
        """Print processing recommendations summary"""
        print(f"\nPROCESSING RECOMMENDATIONS SUMMARY")
        print("-" * 50)
        
        # Collect all recommendations
        all_recommendations = []
        for result in self.results:
            recommendations = self._get_processing_recommendations(result)
            all_recommendations.extend(recommendations)
        
        # Count recommendations
        rec_counts = {}
        for rec in all_recommendations:
            if rec != 'no_action_needed':
                rec_counts[rec] = rec_counts.get(rec, 0) + 1
        
        if rec_counts:
            sorted_recs = sorted(rec_counts.items(), key=lambda x: x[1], reverse=True)
            
            print("Recommended Processing Actions:")
            for rec, count in sorted_recs:
                percentage = count / self.total_pages * 100
                rec_display = rec.replace('_', ' ').title()
                print(f"   • {rec_display}: {count} pages ({percentage:.1f}%)")
        else:
            print("No processing actions recommended!")
    
    def _print_data_tables(self):
        """Print comprehensive data tables"""
        print(f"\nCOMPREHENSIVE DATA TABLES")
        print("-" * 80)
        
        # Create summary table
        print("\nPAGE SUMMARY TABLE:")
        print("-" * 80)
        
        # Headers
        if "Excel" in self.file_type:
            print(f"{'Sheet':<6} {'Name':<15} {'Type':<12} {'Conf':<6} {'Rows':<6} {'Cols':<6} {'Density':<8} {'Verdict':<10} {'Issues':<15}")
        elif self.file_type == "Word Document":
            print(f"{'Page':<6} {'Type':<12} {'Conf':<6} {'Words':<8} {'Paras':<6} {'Images':<7} {'Verdict':<10} {'Issues':<15}")
        else:
            print(f"{'Page':<6} {'Type':<12} {'Conf':<6} {'Blur':<6} {'Cont':<6} {'Skew':<6} {'OCR':<6} {'Verdict':<10} {'Issues':<15}")
        
        print("-" * 80)
        
        # Data rows
        for result in self.results:
            verdict_level = result.document_verdict.quality_level.upper() if result.document_verdict else 'N/A'
            issues_str = ','.join(result.issues[:2])[:14] if result.issues != ['ok'] else 'None'
            
            if "Excel" in self.file_type and result.content_info:
                dims = result.content_info.get('dimensions', {})
                density = result.content_info.get('data_summary', {}).get('data_density', 0)
                sheet_name = result.content_info.get('sheet_name', f'Sheet{result.page_num}')[:14]
                
                print(f"{result.page_num:<6} {sheet_name:<15} {result.doc_type:<12} "
                      f"{result.confidence:.3f} {dims.get('rows', 0):<6} {dims.get('columns', 0):<6} "
                      f"{density:.3f} {verdict_level:<10} {issues_str:<15}")
                      
            elif self.file_type == "Word Document" and result.content_info:
                word_count = result.content_info.get('word_count', 0)
                para_count = result.content_info.get('paragraph_count', 0)
                img_count = result.content_info.get('image_count', 0)
                
                print(f"{result.page_num:<6} {result.doc_type:<12} {result.confidence:.3f} "
                      f"{word_count:<8} {para_count:<6} {img_count:<7} {verdict_level:<10} {issues_str:<15}")
                      
            else:
                # Visual documents (PDF, images)
                blur = result.metrics.blur_score
                contrast = result.metrics.contrast_score
                skew = result.metrics.skew_angle
                ocr = result.metrics.ocr_confidence
                
                print(f"{result.page_num:<6} {result.doc_type:<12} {result.confidence:.3f} "
                      f"{blur:<6.1f} {contrast:<6.3f} {skew:<6.1f} {ocr:<6.3f} {verdict_level:<10} {issues_str:<15}")
    
    def _print_document_specific_analysis(self):
        """Print analysis specific to the document type"""
        print(f"\n{self.file_type.upper()} SPECIFIC ANALYSIS")
        print("-" * 50)

        if "Excel" in self.file_type:
            self._print_excel_specific_analysis()
        elif "Word" in self.file_type:
            self._print_word_specific_analysis()
        elif "PDF" in self.file_type:
            self._print_pdf_specific_analysis()
        elif "Image" in self.file_type:
            self._print_image_specific_analysis()

    def _print_excel_specific_analysis(self):
        """Excel-specific analysis"""
        print("SPREADSHEET ANALYSIS:")

        total_rows = sum(r.content_info.get('dimensions', {}).get('rows', 0) for r in self.results if r.content_info)
        total_cols = sum(r.content_info.get('dimensions', {}).get('columns', 0) for r in self.results if r.content_info)
        total_cells = sum(r.content_info.get('data_summary', {}).get('total_cells', 0) for r in self.results if r.content_info)
        filled_cells = sum(r.content_info.get('data_summary', {}).get('filled_cells', 0) for r in self.results if r.content_info)

        print(f"   • Total Sheets: {self.total_pages}")
        print(f"   • Total Rows: {total_rows:,}")
        print(f"   • Total Columns: {total_cols:,}")
        print(f"   • Total Cells: {total_cells:,}")
        print(f"   • Filled Cells: {filled_cells:,} ({filled_cells/max(total_cells,1)*100:.1f}%)")

        # Data quality issues
        quality_issues = []
        for result in self.results:
            if 'high_missing_data' in result.issues:
                quality_issues.append(f"Sheet {result.page_num}: High missing data")
            if 'duplicate_data' in result.issues:
                quality_issues.append(f"Sheet {result.page_num}: Duplicate data detected")
            if 'duplicate_or_blank' in result.issues:
                quality_issues.append(f"Sheet {result.page_num}: Duplicate or blank sheet")

        if quality_issues:
            print(f"   • Data Quality Issues:")
            for issue in quality_issues:
                print(f"     - {issue}")

    def _print_word_specific_analysis(self):
        """Word document specific analysis"""
        print("WORD DOCUMENT ANALYSIS:")

        if self.results and self.results[0].content_info:
            content = self.results[0].content_info
            print(f"   • Word Count: {content.get('word_count', 0):,}")
            print(f"   • Character Count: {content.get('char_count', 0):,}")
            print(f"   • Paragraph Count: {content.get('paragraph_count', 0):,}")
            print(f"   • Embedded Images: {content.get('image_count', 0)}")

            doc_structure = content.get('document_structure', {})
            print(f"   • Has Tables: {'Yes' if doc_structure.get('has_tables', False) else 'No'}")
            print(f"   • Style Count: {doc_structure.get('style_count', 0)}")

    def _print_pdf_specific_analysis(self):
        """PDF-specific analysis"""
        print("PDF DOCUMENT ANALYSIS:")

        # Source type breakdown
        source_types = {}
        text_layers = {}

        for result in self.results:
            source_type = result.source.source_type
            source_types[source_type] = source_types.get(source_type, 0) + 1

            text_layer = result.source.text_layer_type
            text_layers[text_layer] = text_layers.get(text_layer, 0) + 1

        print(f"   • Source Type Distribution:")
        for source_type, count in source_types.items():
            print(f"     - {source_type.replace('_', ' ').title()}: {count} pages ({count/self.total_pages*100:.1f}%)")

        print(f"   • Text Layer Distribution:")
        for text_layer, count in text_layers.items():
            print(f"     - {text_layer.title()}: {count} pages ({count/self.total_pages*100:.1f}%)")

        # Image analysis
        total_images = sum(r.source.image_count for r in self.results)
        pages_with_images = sum(1 for r in self.results if r.source.has_images)
        print(f"   • Total Embedded Images: {total_images}")
        print(f"   • Pages with Images: {pages_with_images} ({pages_with_images/self.total_pages*100:.1f}%)")

        # New metrics analysis
        avg_ocr_confidence = np.mean([r.metrics.ocr_confidence for r in self.results])
        avg_margin_safety = np.mean([r.metrics.margin_safety for r in self.results])
        avg_duplicate_blank = np.mean([r.metrics.duplicate_blank_score for r in self.results])
        avg_compression_artifact = np.mean([r.metrics.compression_artifact_score for r in self.results])
        avg_page_consistency = np.mean([r.metrics.page_consistency for r in self.results])

        print(f"   • Average OCR Confidence: {avg_ocr_confidence:.3f} {'OK' if avg_ocr_confidence > 0.7 else 'LOW'}")
        print(f"   • Average Margin Safety: {avg_margin_safety:.3f} {'OK' if avg_margin_safety > 0.9 else 'LOW'}")
        print(f"   • Average Duplicate/Blank Score: {avg_duplicate_blank:.3f} {'OK' if avg_duplicate_blank > 0.9 else 'LOW'}")
        print(f"   • Average Compression Artifact Score: {avg_compression_artifact:.3f} {'OK' if avg_compression_artifact > 0.7 else 'LOW'}")
        print(f"   • Average Page Consistency: {avg_page_consistency:.3f} {'OK' if avg_page_consistency > 0.9 else 'LOW'}")

    def _print_image_specific_analysis(self):
        """Image-specific analysis"""
        print("IMAGE ANALYSIS:")

        if self.results:
            result = self.results[0]  # Single image
            if result.content_info:
                props = result.content_info.get('image_properties', {})
                print(f"   • Format: {props.get('format', 'Unknown')}")
                print(f"   • Color Mode: {props.get('mode', 'Unknown')}")
                print(f"   • Channels: {props.get('channels', 'Unknown')}")
                print(f"   • File Size: {self._format_file_size(props.get('file_size', 0))}")

                quality = result.content_info.get('quality_assessment', {})
                print(f"   • Estimated DPI: {quality.get('estimated_dpi', 'Unknown')}")
                print(f"   • Compression Detected: {'Yes' if quality.get('compression_detected', False) else 'No'}")
                print(f"   • Likely Document: {'Yes' if quality.get('likely_document', False) else 'No'}")

                # New metrics
                print(f"   • OCR Confidence: {result.metrics.ocr_confidence:.3f} {'OK' if result.metrics.ocr_confidence > 0.7 else 'LOW'}")
                print(f"   • Margin Safety: {result.metrics.margin_safety:.3f} {'OK' if result.metrics.margin_safety > 0.9 else 'LOW'}")
                print(f"   • Compression Artifact Score: {result.metrics.compression_artifact_score:.3f} {'OK' if result.metrics.compression_artifact_score > 0.7 else 'LOW'}")

    def _print_verdict_summary(self):
        """Print summary of verdicts"""
        print(f"\nVERDICT SUMMARY")
        print("-" * 50)
        
        verdict_counts = {'excellent': 0, 'good': 0, 'acceptable': 0, 'poor': 0}
        for result in self.results:
            if result.document_verdict:
                verdict_counts[result.document_verdict.quality_level] += 1
        
        print("Quality Level Distribution:")
        for level, count in verdict_counts.items():
            percentage = count / self.total_pages * 100
            print(f"   • {level.upper()}: {count} pages ({percentage:.1f}%)")
        
        # Most common actions
        action_counts = {}
        for result in self.results:
            if result.document_verdict:
                action = result.document_verdict.action
                action_counts[action] = action_counts.get(action, 0) + 1
        
        if action_counts:
            print("\nRecommended Actions:")
            for action, count in sorted(action_counts.items(), key=lambda x: x[1], reverse=True):
                display_action = action.replace('_', ' ').title()
                percentage = count / self.total_pages * 100
                print(f"   • {display_action}: {count} pages ({percentage:.1f}%)")

def create_progress_callback():
    """Create a simple progress callback for the analyzer"""
    def progress_callback(current: int, total: int):
        if total > 1:
            percent = (current / total) * 100
            print(f"Progress: {current}/{total} ({percent:.1f}%)", end='\r')
    return progress_callback


def main():
    """Main function with command-line interface"""
    parser = argparse.ArgumentParser(
        description="Universal Document Analyzer - Analyze PDF, DOCX, XLSX, and image files",
        formatter_class=argparse.RawDescriptionHelpFormatter,
        epilog="""
Examples:
    python universal_analyzer.py document.pdf
    python universal_analyzer.py spreadsheet.xlsx --no-stats
    python universal_analyzer.py image.jpg --no-recommendations
    python universal_analyzer.py report.docx --output results.json
        """
    )

    parser.add_argument('file_path', help='Path to the document file to analyze')
    parser.add_argument('--output', '-o', help='Save results to JSON file')
    parser.add_argument('--no-stats', action='store_true', help='Skip statistical analysis')
    parser.add_argument('--no-recommendations', action='store_true', help='Skip processing recommendations')
    parser.add_argument('--no-quality-flags', action='store_true', help='Skip quality flags')
    parser.add_argument('--workers', '-w', type=int, help='Number of worker threads (default: auto)')
    parser.add_argument('--quiet', '-q', action='store_true', help='Minimal output (just summary)')
    parser.add_argument('--config', '-c', default="TresholdConfig.json", help='Path to threshold config JSON (default: TresholdConfig.json)')

    args = parser.parse_args()

    # Validate file exists
    if not os.path.exists(args.file_path):
        print(f"Error: File '{args.file_path}' not found.")
        sys.exit(1)

    try:
        print("Universal Document Analyzer Starting...")
        print(f"Target File: {args.file_path}")

        # Initialize analyzer
        analyzer = UniversalDocumentAnalyzer(max_workers=args.workers, config_path=args.config)

        # Create progress callback
        progress_callback = None if args.quiet else create_progress_callback()

        # Analyze document
        start_time = time.time()
        results = analyzer.analyze_document(args.file_path, progress_callback)
        analysis_time = time.time() - start_time

        if not results:
            print("No results obtained from analysis.")
            sys.exit(1)

        # Print results
        if not args.quiet:
            printer = UniversalDocumentPrinter(results, args.file_path)
            printer.print_everything(
                show_recommendations=not args.no_recommendations,
                show_statistics=not args.no_stats,
                show_quality_flags=not args.no_quality_flags
            )
        else:
            # Quiet mode - just summary
            digital = sum(1 for r in results if r.doc_type == 'digital')
            good_scan = sum(1 for r in results if r.doc_type == 'good_scan')
            poor_scan = sum(1 for r in results if r.doc_type == 'poor_scan')

            print("\nQUICK SUMMARY:")
            print(f"Total Pages/Sheets: {len(results)}")
            print(f"Digital: {digital}, Good Scans: {good_scan}, Poor Scans: {poor_scan}")
            print(f"Analysis Time: {analysis_time:.2f}s")

        # Save to JSON if requested
        if args.output:
            save_results_to_json(results, args.file_path, args.output)
            print(f"\nResults saved to {args.output}")

        print(f"\nAnalysis completed successfully in {analysis_time:.2f}s")

    except Exception as e:
        print(f"Analysis failed: {e}")
        if not args.quiet:
            import traceback
            traceback.print_exc()
        sys.exit(1)


def save_results_to_json(results: List[PageAnalysis],
                         file_path: str, output_path: str):
    """Save analysis results to JSON file"""

    def convert_to_serializable(obj):
        """Convert dataclass objects to dictionaries"""
        if hasattr(obj, '__dict__'):
            result = {}
            for key, value in obj.__dict__.items():
                if hasattr(value, '__dict__'):
                    result[key] = convert_to_serializable(value)
                elif isinstance(value, (list, tuple)):
                    result[key] = [
                        convert_to_serializable(item) for item in value
                        ]
                elif isinstance(value, np.ndarray):
                    result[key] = value.tolist()
                elif isinstance(value, np.generic):
                    result[key] = value.item()
                else:
                    result[key] = value
            return result
        else:
            return obj

    output_data = {
        'analysis_metadata': {
            'file_path': str(file_path),
            'analysis_date': datetime.now().isoformat(),
            'total_pages': len(results),
            'analyzer_version': '1.0.0'
        },
        'results': [convert_to_serializable(result) for result in results]
    }

    with open(output_path, 'w', encoding='utf-8') as f:
        json.dump(output_data, f, indent=2, ensure_ascii=False)


if __name__ == "__main__":
    main()
