"""
Core Logic Package
Contains the main document processing algorithms
"""

__all__ = ["document_classifier", "quality_analyzer"]
