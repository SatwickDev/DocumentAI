"""
MCP Document Processing System
Main package initialization
"""

__version__ = "2.0.0"
__author__ = "Document Processing Team"
__description__ = "MCP-based document classification and quality analysis system"
