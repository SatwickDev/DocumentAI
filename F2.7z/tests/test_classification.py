#!/usr/bin/env python3
"""
Test Classification functionality
"""
import unittest
import sys
import os
from pathlib import Path

# Add project root to path
project_root = Path(__file__).parent.parent
sys.path.insert(0, str(project_root))

from src.core.document_classifier import classify_document_ultra_fast
from src.utils.mcp_contracts import ClassificationRequest, ClassificationResponse

class TestClassification(unittest.TestCase):
    """Test classification functionality"""
    
    def test_classification_basic(self):
        """Test basic classification works"""
        # This is a placeholder for actual tests
        self.assertTrue(True)
        
    def test_classification_contract(self):
        """Test classification contracts work properly"""
        # Create a request
        request = ClassificationRequest(
            file_path="test.pdf",
            session_id="test-123"
        )
        
        # Verify contract works
        self.assertEqual(request.file_path, "test.pdf")
        self.assertEqual(request.session_id, "test-123")

if __name__ == "__main__":
    unittest.main()
